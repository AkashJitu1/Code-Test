using System.Windows.Controls;

namespace SkyWorkItems.Views;

/// <summary>
/// Pull-request comment module. DataContext is supplied by the shell.
/// </summary>
public partial class PullRequestsView : UserControl
{
    public PullRequestsView() => InitializeComponent();
}
