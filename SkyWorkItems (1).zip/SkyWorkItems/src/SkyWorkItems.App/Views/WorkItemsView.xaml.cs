using System.Windows.Controls;

namespace SkyWorkItems.Views;

/// <summary>
/// Work-item module. The DataContext is supplied by the shell
/// (<c>DataContext="{Binding WorkItems}"</c>), so this view has no constructor
/// dependencies of its own.
/// </summary>
public partial class WorkItemsView : UserControl
{
    public WorkItemsView() => InitializeComponent();
}
