using System.Windows;
using SkyWorkItems.ViewModels;

namespace SkyWorkItems.Views;

public partial class MainWindow : Window
{
    public MainWindow(ShellViewModel viewModel)
    {
        InitializeComponent();
        DataContext = viewModel;

        // Teams are the entry point for the work-item module, so load them once the
        // window is up rather than blocking the constructor.
        Loaded += async (_, _) => await viewModel.WorkItems.LoadTeamsCommand.ExecuteAsync(null);
    }
}
