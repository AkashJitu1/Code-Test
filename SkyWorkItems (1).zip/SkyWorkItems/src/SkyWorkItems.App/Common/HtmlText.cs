using System.Net;
using System.Text.RegularExpressions;

namespace SkyWorkItems.Common;

/// <summary>
/// Azure DevOps returns rich-text fields as HTML. Copilot and PDF both want plain
/// text, so flatten it here. Deliberately regex-based: no extra dependency for what
/// is a small, well-known subset of markup.
/// </summary>
public static partial class HtmlText
{
    public static string ToPlainText(string? html)
    {
        if (string.IsNullOrWhiteSpace(html))
            return string.Empty;

        var text = html;
        text = LineBreak().Replace(text, "\n");
        text = ListItemStart().Replace(text, "- ");
        text = BlockEnd().Replace(text, "\n");
        text = AnyTag().Replace(text, string.Empty);
        text = WebUtility.HtmlDecode(text);
        text = text.Replace('\u00a0', ' ').Replace("\r\n", "\n").Replace('\r', '\n');
        text = TrailingSpace().Replace(text, "\n");
        text = ExtraBlankLines().Replace(text, "\n\n");
        return text.Trim();
    }

    [GeneratedRegex(@"<\s*br\s*/?\s*>", RegexOptions.IgnoreCase)]
    private static partial Regex LineBreak();

    [GeneratedRegex(@"<\s*li[^>]*>", RegexOptions.IgnoreCase)]
    private static partial Regex ListItemStart();

    [GeneratedRegex(@"<\s*/\s*(p|div|li|ul|ol|tr|h[1-6])\s*>", RegexOptions.IgnoreCase)]
    private static partial Regex BlockEnd();

    [GeneratedRegex("<[^>]+>")]
    private static partial Regex AnyTag();

    [GeneratedRegex(@"[ \t]+\n")]
    private static partial Regex TrailingSpace();

    [GeneratedRegex(@"\n{3,}")]
    private static partial Regex ExtraBlankLines();
}
