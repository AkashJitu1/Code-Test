using System.Text.RegularExpressions;

namespace SkyWorkItems.Common;

public static partial class FileNames
{
    /// <summary>"660033 - Allow bulk upload" -> a safe, readable file stem.</summary>
    public static string Safe(int id, string? title, int maxTitleLength = 70)
    {
        var clean = Invalid().Replace(title ?? string.Empty, " ").Trim();
        clean = Whitespace().Replace(clean, " ");

        if (clean.Length > maxTitleLength)
            clean = clean[..maxTitleLength].TrimEnd();

        return string.IsNullOrEmpty(clean) ? id.ToString() : $"{id} - {clean}";
    }

    [GeneratedRegex(@"[^\w\-\. ]")]
    private static partial Regex Invalid();

    [GeneratedRegex(@"\s+")]
    private static partial Regex Whitespace();
}
