using System.Collections;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace SkyWorkItems.Common;

/// <summary>
/// Collapses an element when the bound value is null. Pass "Invert" as the converter
/// parameter to show the element only when the value IS null — used for the
/// "nothing selected yet" placeholders.
/// </summary>
public sealed class NullToVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var hasValue = value is not null;

        if (IsInverted(parameter))
            hasValue = !hasValue;

        return hasValue ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => Binding.DoNothing;

    internal static bool IsInverted(object? parameter)
        => string.Equals(parameter as string, "Invert", StringComparison.OrdinalIgnoreCase);
}

/// <summary>Collapses an element when the bound string is null, empty or whitespace.</summary>
public sealed class EmptyStringToVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var hasText = !string.IsNullOrWhiteSpace(value as string);

        if (NullToVisibilityConverter.IsInverted(parameter))
            hasText = !hasText;

        return hasText ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => Binding.DoNothing;
}

/// <summary>
/// Collapses an element when the bound collection (or count) is empty. Accepts either an
/// <see cref="ICollection"/> or a number so it can be bound to either Items or Items.Count.
/// </summary>
public sealed class EmptyCollectionToVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var count = value switch
        {
            null => 0,
            int number => number,
            ICollection collection => collection.Count,
            IEnumerable enumerable => enumerable.Cast<object>().Take(1).Count(),
            _ => 0
        };

        var hasItems = count > 0;

        if (NullToVisibilityConverter.IsInverted(parameter))
            hasItems = !hasItems;

        return hasItems ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => Binding.DoNothing;
}

/// <summary>Flips a boolean — for "enabled while not busy" style bindings.</summary>
public sealed class InverseBooleanConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is not true;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is not true;
}
