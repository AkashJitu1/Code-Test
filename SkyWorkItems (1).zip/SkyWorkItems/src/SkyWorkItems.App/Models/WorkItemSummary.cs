using CommunityToolkit.Mvvm.ComponentModel;

namespace SkyWorkItems.Models;

/// <summary>Row in the work item grid. Observable because of the export checkbox.</summary>
public sealed partial class WorkItemSummary : ObservableObject
{
    [ObservableProperty]
    private bool _isSelected = true;

    public int Id { get; init; }
    public string Title { get; init; } = string.Empty;
    public string WorkItemType { get; init; } = string.Empty;
    public string State { get; init; } = string.Empty;
    public string AssignedTo { get; init; } = string.Empty;
    public string IterationPath { get; init; } = string.Empty;

    public string Display => $"[{Id}] {Title}";
}
