namespace SkyWorkItems.Models;

public sealed record ChatTurn(string Role, string Content)
{
    public bool IsUser => Role == "User";
    public static ChatTurn User(string text) => new("User", text);
    public static ChatTurn Assistant(string name, string text) => new(name, text);
}
