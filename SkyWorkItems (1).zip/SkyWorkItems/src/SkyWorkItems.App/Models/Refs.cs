namespace SkyWorkItems.Models;

public sealed record TeamRef(string Id, string Name)
{
    public override string ToString() => Name;
}

public sealed record IterationRef(string Id, string Name, string Path, DateTime? StartDate, DateTime? FinishDate)
{
    public string Display => StartDate is null || FinishDate is null
        ? Name
        : $"{Name}  ({StartDate:dd MMM} - {FinishDate:dd MMM yyyy})";

    public override string ToString() => Display;
}

public sealed record DiscussionComment(string Author, DateTime CreatedDate, string Text);
