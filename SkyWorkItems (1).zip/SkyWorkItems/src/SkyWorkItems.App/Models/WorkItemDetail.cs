namespace SkyWorkItems.Models;

/// <summary>Everything the exporters and the AI agent need about one work item.</summary>
public sealed class WorkItemDetail
{
    public int Id { get; init; }
    public string Title { get; init; } = string.Empty;
    public string WorkItemType { get; init; } = string.Empty;
    public string State { get; init; } = string.Empty;
    public string AssignedTo { get; init; } = string.Empty;
    public string IterationPath { get; init; } = string.Empty;
    public string AreaPath { get; init; } = string.Empty;
    public string Tags { get; init; } = string.Empty;
    public string WebUrl { get; init; } = string.Empty;

    public string Description { get; init; } = string.Empty;
    public string AcceptanceCriteria { get; init; } = string.Empty;
    public string RefinementNotes { get; init; } = string.Empty;
    public string DevelopmentNotes { get; init; } = string.Empty;
    public string TestingNotes { get; init; } = string.Empty;

    public IReadOnlyList<DiscussionComment> Discussion { get; init; } = [];
}
