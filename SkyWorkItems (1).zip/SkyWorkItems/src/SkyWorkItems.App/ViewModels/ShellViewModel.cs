using Microsoft.Extensions.Options;
using SkyWorkItems.Configuration;

namespace SkyWorkItems.ViewModels;

/// <summary>
/// Top-level window ViewModel. It owns nothing of its own beyond the caption — it just
/// holds the two module ViewModels so each tab keeps its own state, commands and status
/// line instead of everything piling into one class.
/// </summary>
public sealed class ShellViewModel
{
    public ShellViewModel(
        MainViewModel workItems,
        PullRequestsViewModel pullRequests,
        IOptions<AppSettings> settings)
    {
        WorkItems = workItems;
        PullRequests = pullRequests;

        var devOps = settings.Value.AzureDevOps;
        Organization = devOps.Organization;
        Project = devOps.Project;
    }

    public MainViewModel WorkItems { get; }

    public PullRequestsViewModel PullRequests { get; }

    public string Organization { get; }

    public string Project { get; }

    public string ProjectCaption => $"{Organization} / {Project}";
}
