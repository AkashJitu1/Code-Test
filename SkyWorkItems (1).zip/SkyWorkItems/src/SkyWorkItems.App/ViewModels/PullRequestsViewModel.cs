using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Data;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SkyWorkItems.Configuration;
using SkyWorkItems.Services.DevOps;
using SkyWorkItems.Services.Shell;

namespace SkyWorkItems.ViewModels;

/// <summary>
/// Drives the "PR comments" module: builds a <see cref="PullRequestCommentFilter"/> from
/// the form, runs <see cref="IPullRequestCommentService"/>, and exposes the results for
/// the grid, the detail pane and the Markdown export.
/// </summary>
public sealed partial class PullRequestsViewModel : ObservableObject
{
    private readonly IPullRequestCommentService _service;
    private readonly IFolderPicker _folderPicker;
    private readonly IDocumentPrinter _printer;
    private readonly AppSettings _settings;
    private readonly ILogger<PullRequestsViewModel> _log;

    /// <summary>
    /// The filter that produced the current results. Kept so the export reports the same
    /// criteria that were actually run, not whatever the form has been edited to since.
    /// </summary>
    private PullRequestCommentFilter _lastRunFilter = new();

    public PullRequestsViewModel(
        IPullRequestCommentService service,
        IFolderPicker folderPicker,
        IDocumentPrinter printer,
        IOptions<AppSettings> settings,
        ILogger<PullRequestsViewModel> log)
    {
        _service = service;
        _folderPicker = folderPicker;
        _printer = printer;
        _settings = settings.Value;
        _log = log;

        CommentsView = CollectionViewSource.GetDefaultView(Comments);
        CommentsView.Filter = MatchesSearch;

        OutputDirectory = _settings.Export.ResolveDirectory();
        Status = "Set a date range and search.";
    }

    // ----- collections -------------------------------------------------------

    public ObservableCollection<ReviewComment> Comments { get; } = [];

    public ICollectionView CommentsView { get; }

    public string[] StatusOptions { get; } = ["all", "active", "completed", "abandoned"];

    // ----- filter form -------------------------------------------------------

    [ObservableProperty] private DateTime? _fromDate = DateTime.Today.AddDays(-30);
    [ObservableProperty] private DateTime? _toDate = DateTime.Today;

    /// <summary>Comma-separated; partial names and email aliases both work.</summary>
    [ObservableProperty] private string _reviewerNames = string.Empty;

    /// <summary>Comma-separated repository names. Blank means every repository.</summary>
    [ObservableProperty] private string _repositoryNames = string.Empty;

    [ObservableProperty] private string _pullRequestStatus = "all";
    [ObservableProperty] private string _targetBranch = string.Empty;
    [ObservableProperty] private bool _includeReplies = true;
    [ObservableProperty] private bool _includeSystemComments;
    [ObservableProperty] private bool _includeCodeSnippets = true;
    [ObservableProperty] private int _codeContextLines = 2;
    [ObservableProperty] private int _maxPullRequests = 300;

    // ----- results -----------------------------------------------------------

    [ObservableProperty] private ReviewComment? _selectedComment;
    [ObservableProperty] private string _searchText = string.Empty;
    [ObservableProperty] private string _outputDirectory = string.Empty;
    [ObservableProperty] private string _status = string.Empty;

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(IsIdle))]
    private bool _isBusy;

    public bool IsIdle => !IsBusy;

    public string ResultCaption
    {
        get
        {
            if (Comments.Count == 0)
                return "No comments loaded";

            var visible = CommentsView.Cast<object>().Count();
            var pullRequests = Comments.Select(c => c.PullRequestId).Distinct().Count();

            return visible == Comments.Count
                ? $"{Comments.Count} comment(s) across {pullRequests} PR(s)"
                : $"{visible} of {Comments.Count} shown";
        }
    }

    // ----- search ------------------------------------------------------------

    partial void OnSearchTextChanged(string value)
    {
        CommentsView.Refresh();
        OnPropertyChanged(nameof(ResultCaption));
    }

    /// <summary>
    /// One box, every column. Terms are ANDed, so "660 ravi .cs" narrows by PR, reviewer
    /// and file in a single expression.
    /// </summary>
    private bool MatchesSearch(object item)
    {
        if (string.IsNullOrWhiteSpace(SearchText))
            return true;

        if (item is not ReviewComment comment)
            return false;

        var haystack = string.Join(' ',
            comment.PullRequestId,
            comment.PullRequestTitle,
            comment.RepositoryName,
            comment.ReviewerName,
            comment.ReviewerEmail,
            comment.FilePath,
            comment.Content);

        var terms = SearchText.Split(' ', StringSplitOptions.RemoveEmptyEntries
                                        | StringSplitOptions.TrimEntries);

        return terms.All(term => haystack.Contains(term, StringComparison.OrdinalIgnoreCase));
    }

    [RelayCommand]
    private void ClearSearch() => SearchText = string.Empty;

    // ----- commands ----------------------------------------------------------

    [RelayCommand]
    private async Task SearchAsync()
    {
        await RunAsync("Searching pull request comments…", async ct =>
        {
            var filter = BuildFilter();
            _lastRunFilter = filter;

            Comments.Clear();
            SelectedComment = null;

            var progress = new Progress<string>(message => Status = message);
            var results = await _service.GetCommentsAsync(filter, progress, ct);

            foreach (var comment in results)
                Comments.Add(comment);

            OnPropertyChanged(nameof(ResultCaption));

            Status = results.Count == 0
                ? "No comments matched the filter."
                : $"Found {results.Count} comment(s) across "
                  + $"{results.Select(c => c.PullRequestId).Distinct().Count()} pull request(s).";
        });
    }

    [RelayCommand]
    private async Task ExportMarkdownAsync()
    {
        if (Comments.Count == 0)
        {
            Status = "Run a search first.";
            return;
        }

        await RunAsync("Writing Markdown…", async ct =>
        {
            // Export what the user is looking at: if the search box has narrowed the grid,
            // the file matches the grid rather than the full result set.
            var toExport = CommentsView.Cast<ReviewComment>().ToList();

            var path = await _service.ExportMarkdownAsync(toExport, _lastRunFilter, OutputDirectory, ct: ct);
            Status = $"Wrote {toExport.Count} comment(s) to {path}";
        });
    }

    [RelayCommand]
    private void ClearFilters()
    {
        FromDate = DateTime.Today.AddDays(-30);
        ToDate = DateTime.Today;
        ReviewerNames = string.Empty;
        RepositoryNames = string.Empty;
        TargetBranch = string.Empty;
        PullRequestStatus = "all";
        IncludeReplies = true;
        IncludeSystemComments = false;
        IncludeCodeSnippets = true;
        CodeContextLines = 2;
        SearchText = string.Empty;
        Status = "Filters reset.";
    }

    [RelayCommand]
    private void BrowseOutputFolder()
    {
        var picked = _folderPicker.Pick("Choose where the Markdown report goes", OutputDirectory);
        if (!string.IsNullOrWhiteSpace(picked))
            OutputDirectory = picked;
    }

    [RelayCommand]
    private void OpenOutputFolder()
    {
        Directory.CreateDirectory(OutputDirectory);
        Process.Start(new ProcessStartInfo(OutputDirectory) { UseShellExecute = true });
    }

    [RelayCommand]
    private void OpenInDevOps()
    {
        if (SelectedComment is null)
            return;

        Process.Start(new ProcessStartInfo(SelectedComment.CommentUrl) { UseShellExecute = true });
    }

    [RelayCommand]
    private void CopyComment()
    {
        if (SelectedComment is null)
            return;

        _printer.CopyToClipboard(FormatForClipboard(SelectedComment));
        Status = "Comment copied to the clipboard.";
    }

    [RelayCommand]
    private void CopySnippet()
    {
        if (string.IsNullOrWhiteSpace(SelectedComment?.CodeSnippet))
            return;

        _printer.CopyToClipboard(SelectedComment.CodeSnippet!);
        Status = "Code snippet copied to the clipboard.";
    }

    /// <summary>Prints the rows currently visible in the grid, one section per comment.</summary>
    [RelayCommand]
    private void PrintComments()
    {
        var visible = CommentsView.Cast<ReviewComment>().ToList();
        if (visible.Count == 0)
        {
            Status = "Nothing to print yet.";
            return;
        }

        var sections = new List<PrintSection>();

        foreach (var comment in visible)
        {
            sections.Add(new PrintSection(
                $"PR {comment.PullRequestId} — {comment.ReviewerName} — "
                + $"{comment.CommentDate.LocalDateTime:dd MMM yyyy HH:mm}",
                $"{comment.LocationCaption}\n{comment.Content}"));

            if (!string.IsNullOrWhiteSpace(comment.CodeSnippet))
                sections.Add(new PrintSection(string.Empty, comment.CodeSnippet!, Monospaced: true));
        }

        if (_printer.Print("Pull request review comments", sections))
            Status = $"Sent {visible.Count} comment(s) to the printer.";
    }

    // ----- helpers -----------------------------------------------------------

    /// <summary>
    /// Maps the form onto the service filter.
    ///
    /// Note the date split: FromDate/ToDate bound the <i>comment</i> date, while the PR
    /// creation window is deliberately left open. A PR raised months ago can still pick
    /// up a review comment yesterday, and narrowing the PR list would hide exactly that.
    /// </summary>
    private PullRequestCommentFilter BuildFilter() => new()
    {
        FromDate = ToOffset(FromDate),
        ToDate = ToOffset(ToDate),
        ReviewerNames = SplitList(ReviewerNames),
        RepositoryNames = SplitList(RepositoryNames),
        PullRequestStatus = string.IsNullOrWhiteSpace(PullRequestStatus) ? "all" : PullRequestStatus,
        TargetBranch = string.IsNullOrWhiteSpace(TargetBranch) ? null : TargetBranch.Trim(),
        IncludeReplies = IncludeReplies,
        IncludeSystemComments = IncludeSystemComments,
        IncludeCodeSnippets = IncludeCodeSnippets,
        CodeContextLines = Math.Clamp(CodeContextLines, 0, 10),
        MaxPullRequests = Math.Clamp(MaxPullRequests, 1, 2000)
    };

    /// <summary>Splits "Akash, priya.s@, Ravi" into trimmed, non-empty entries.</summary>
    private static IReadOnlyList<string> SplitList(string? value)
        => string.IsNullOrWhiteSpace(value)
            ? []
            : value.Split([',', ';'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

    /// <summary>
    /// The DatePicker hands back a local midnight DateTime. Converting through
    /// <see cref="DateTimeOffset"/> keeps the user's offset, which matters because the
    /// service compares against UTC timestamps from the API.
    /// </summary>
    private static DateTimeOffset? ToOffset(DateTime? value)
        => value is null ? null : new DateTimeOffset(DateTime.SpecifyKind(value.Value, DateTimeKind.Local));

    private static string FormatForClipboard(ReviewComment comment)
    {
        var builder = new StringBuilder();
        builder.AppendLine($"PR {comment.PullRequestId} — {comment.PullRequestTitle}");
        builder.AppendLine($"Reviewer: {comment.ReviewerName}");
        builder.AppendLine($"Date: {comment.CommentDate.LocalDateTime:dd MMM yyyy HH:mm}");
        builder.AppendLine($"Location: {comment.LocationCaption}");
        builder.AppendLine($"Link: {comment.CommentUrl}");
        builder.AppendLine();

        if (!string.IsNullOrWhiteSpace(comment.CodeSnippet))
            builder.AppendLine(comment.CodeSnippet).AppendLine();

        builder.AppendLine(comment.Content);
        return builder.ToString();
    }

    /// <summary>Shared busy state, cancellation and error reporting for every command.</summary>
    private async Task RunAsync(string busyMessage, Func<CancellationToken, Task> work)
    {
        if (IsBusy)
            return;

        IsBusy = true;
        Status = busyMessage;

        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(15));
            await work(cts.Token);
        }
        catch (OperationCanceledException)
        {
            Status = "Cancelled — the search took too long.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Pull request comment operation failed: {Message}", busyMessage);
            Status = "Error: " + ex.Message.Replace('\n', ' ');
        }
        finally
        {
            IsBusy = false;
        }
    }
}
