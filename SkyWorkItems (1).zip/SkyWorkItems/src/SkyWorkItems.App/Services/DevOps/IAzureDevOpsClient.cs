using SkyWorkItems.Models;

namespace SkyWorkItems.Services.DevOps;

/// <summary>
/// Read-only view over the Azure DevOps work tracking API that this app needs.
/// Kept narrow on purpose (ISP) so it can be faked in tests without a PAT.
/// </summary>
public interface IAzureDevOpsClient
{
    Task<IReadOnlyList<TeamRef>> GetTeamsAsync(CancellationToken ct = default);

    Task<IReadOnlyList<IterationRef>> GetIterationsAsync(string teamName, CancellationToken ct = default);

    Task<IReadOnlyList<int>> QueryWorkItemIdsAsync(string teamName, string iterationPath, CancellationToken ct = default);

    Task<IReadOnlyList<WorkItemSummary>> GetSummariesAsync(IReadOnlyList<int> ids, CancellationToken ct = default);

    Task<WorkItemDetail> GetDetailAsync(int id, CancellationToken ct = default);
}
