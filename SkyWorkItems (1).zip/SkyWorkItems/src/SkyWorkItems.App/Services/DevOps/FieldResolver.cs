using System.Text.Json;
using System.Text.RegularExpressions;

namespace SkyWorkItems.Services.DevOps;

/// <summary>
/// "Refinement Notes", "Development Notes" and "Testing Notes" are custom fields, so
/// their reference names differ per organisation (Custom.RefinementNotes,
/// Sky.Refinement_Notes, WEF_xxx_Kanban..., and so on). Configure the exact name in
/// appsettings.json if you know it; otherwise we match on a normalised field name.
/// </summary>
internal static partial class FieldResolver
{
    public static string Resolve(
        IReadOnlyDictionary<string, JsonElement> fields,
        string configuredReferenceName,
        params string[] hints)
    {
        if (!string.IsNullOrWhiteSpace(configuredReferenceName)
            && fields.TryGetValue(configuredReferenceName, out var configured))
        {
            return AsString(configured);
        }

        foreach (var hint in hints)
        {
            var needle = Normalise(hint);

            foreach (var (key, value) in fields)
            {
                if (!Normalise(key).Contains(needle, StringComparison.Ordinal))
                    continue;

                var text = AsString(value);
                if (!string.IsNullOrWhiteSpace(text))
                    return text;
            }
        }

        return string.Empty;
    }

    /// <summary>Reads a field that may be a string, a number, or an identity object.</summary>
    public static string AsString(JsonElement element) => element.ValueKind switch
    {
        JsonValueKind.String => element.GetString() ?? string.Empty,
        JsonValueKind.Number => element.ToString(),
        JsonValueKind.True or JsonValueKind.False => element.GetRawText(),
        JsonValueKind.Object => element.TryGetProperty("displayName", out var name)
            ? name.GetString() ?? string.Empty
            : string.Empty,
        _ => string.Empty
    };

    public static string Field(IReadOnlyDictionary<string, JsonElement> fields, string referenceName)
        => fields.TryGetValue(referenceName, out var value) ? AsString(value) : string.Empty;

    private static string Normalise(string value)
        => NonAlphaNumeric().Replace(value, string.Empty).ToLowerInvariant();

    [GeneratedRegex(@"[^A-Za-z0-9]")]
    private static partial Regex NonAlphaNumeric();
}
