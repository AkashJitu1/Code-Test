using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SkyWorkItems.Common;
using SkyWorkItems.Configuration;
using SkyWorkItems.Models;

namespace SkyWorkItems.Services.DevOps;

/// <summary>
/// Talks to the Azure DevOps REST API (7.1) over a PAT-authenticated HttpClient.
/// The client is configured in App.xaml.cs; this class only builds URLs and maps JSON.
/// </summary>
public sealed class AzureDevOpsClient : IAzureDevOpsClient
{
    private const int BatchSize = 200; // workitemsbatch hard limit

    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    private readonly HttpClient _http;
    private readonly AzureDevOpsOptions _options;
    private readonly ILogger<AzureDevOpsClient> _log;

    public AzureDevOpsClient(
        HttpClient http,
        IOptions<AppSettings> settings,
        ILogger<AzureDevOpsClient> log)
    {
        _http = http;
        _options = settings.Value.AzureDevOps;
        _log = log;
    }

    private string Org => Uri.EscapeDataString(_options.Organization);
    private string Project => Uri.EscapeDataString(_options.Project);
    private string Api => _options.ApiVersion;

    public async Task<IReadOnlyList<TeamRef>> GetTeamsAsync(CancellationToken ct = default)
    {
        var url = $"{Org}/_apis/projects/{Project}/teams?api-version={Api}&$top=500";
        using var doc = await GetJsonAsync(url, ct);

        var teams = new List<TeamRef>();
        foreach (var team in doc.RootElement.GetProperty("value").EnumerateArray())
        {
            teams.Add(new TeamRef(
                team.GetProperty("id").GetString() ?? string.Empty,
                team.GetProperty("name").GetString() ?? string.Empty));
        }

        return teams.OrderBy(t => t.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }

    public async Task<IReadOnlyList<IterationRef>> GetIterationsAsync(string teamName, CancellationToken ct = default)
    {
        var team = Uri.EscapeDataString(teamName);
        var url = $"{Org}/{Project}/{team}/_apis/work/teamsettings/iterations?api-version={Api}";
        using var doc = await GetJsonAsync(url, ct);

        var iterations = new List<IterationRef>();
        foreach (var item in doc.RootElement.GetProperty("value").EnumerateArray())
        {
            DateTime? start = null, finish = null;
            if (item.TryGetProperty("attributes", out var attributes))
            {
                start = ReadDate(attributes, "startDate");
                finish = ReadDate(attributes, "finishDate");
            }

            iterations.Add(new IterationRef(
                item.GetProperty("id").GetString() ?? string.Empty,
                item.GetProperty("name").GetString() ?? string.Empty,
                item.TryGetProperty("path", out var path) ? path.GetString() ?? string.Empty : string.Empty,
                start,
                finish));
        }

        return iterations.OrderByDescending(i => i.StartDate ?? DateTime.MinValue).ToList();
    }

    public async Task<IReadOnlyList<int>> QueryWorkItemIdsAsync(
        string teamName, string iterationPath, CancellationToken ct = default)
    {
        var types = string.Join(", ", _options.WorkItemTypes.Select(t => $"'{Escape(t)}'"));

        // The iteration path returned by the teamsettings API is "Sky\Sprint 12"
        // for a project named Sky, which is exactly what System.IterationPath stores.
        var wiql = $"""
            SELECT [System.Id]
            FROM WorkItems
            WHERE [System.TeamProject] = '{Escape(_options.Project)}'
              AND [System.IterationPath] = '{Escape(iterationPath)}'
              AND [System.WorkItemType] IN ({types})
            ORDER BY [System.WorkItemType], [System.Id]
            """;

        var team = Uri.EscapeDataString(teamName);
        var url = $"{Org}/{Project}/{team}/_apis/wit/wiql?api-version={Api}";

        using var response = await _http.PostAsJsonAsync(url, new { query = wiql }, Json, ct);
        await EnsureSuccessAsync(response, url, ct);

        using var doc = await JsonDocument.ParseAsync(
            await response.Content.ReadAsStreamAsync(ct), cancellationToken: ct);

        var ids = new List<int>();
        if (doc.RootElement.TryGetProperty("workItems", out var workItems))
        {
            foreach (var item in workItems.EnumerateArray())
                ids.Add(item.GetProperty("id").GetInt32());
        }

        _log.LogInformation("WIQL returned {Count} work items for {Iteration}", ids.Count, iterationPath);
        return ids;
    }

    public async Task<IReadOnlyList<WorkItemSummary>> GetSummariesAsync(
        IReadOnlyList<int> ids, CancellationToken ct = default)
    {
        var results = new List<WorkItemSummary>(ids.Count);

        foreach (var chunk in ids.Chunk(BatchSize))
        {
            var url = $"{Org}/{Project}/_apis/wit/workitemsbatch?api-version={Api}";
            var payload = new
            {
                ids = chunk,
                fields = new[]
                {
                    "System.Id", "System.Title", "System.WorkItemType",
                    "System.State", "System.AssignedTo", "System.IterationPath"
                }
            };

            using var response = await _http.PostAsJsonAsync(url, payload, Json, ct);
            await EnsureSuccessAsync(response, url, ct);

            using var doc = await JsonDocument.ParseAsync(
                await response.Content.ReadAsStreamAsync(ct), cancellationToken: ct);

            foreach (var item in doc.RootElement.GetProperty("value").EnumerateArray())
            {
                var fields = ReadFields(item);
                results.Add(new WorkItemSummary
                {
                    Id = item.GetProperty("id").GetInt32(),
                    Title = FieldResolver.Field(fields, "System.Title"),
                    WorkItemType = FieldResolver.Field(fields, "System.WorkItemType"),
                    State = FieldResolver.Field(fields, "System.State"),
                    AssignedTo = FieldResolver.Field(fields, "System.AssignedTo"),
                    IterationPath = FieldResolver.Field(fields, "System.IterationPath")
                });
            }
        }

        return results;
    }

    public async Task<WorkItemDetail> GetDetailAsync(int id, CancellationToken ct = default)
    {
        var url = $"{Org}/{Project}/_apis/wit/workitems/{id}?api-version={Api}&$expand=all";
        using var doc = await GetJsonAsync(url, ct);

        var fields = ReadFields(doc.RootElement);
        var map = _options.Fields;

        return new WorkItemDetail
        {
            Id = id,
            Title = FieldResolver.Field(fields, "System.Title"),
            WorkItemType = FieldResolver.Field(fields, "System.WorkItemType"),
            State = FieldResolver.Field(fields, "System.State"),
            AssignedTo = FieldResolver.Field(fields, "System.AssignedTo"),
            IterationPath = FieldResolver.Field(fields, "System.IterationPath"),
            AreaPath = FieldResolver.Field(fields, "System.AreaPath"),
            Tags = FieldResolver.Field(fields, "System.Tags"),
            WebUrl = BuildWebUrl(id),

            Description = Clean(FieldResolver.Resolve(fields, "System.Description", "description")),
            AcceptanceCriteria = Clean(FieldResolver.Resolve(fields, map.AcceptanceCriteria, "acceptancecriteria")),
            RefinementNotes = Clean(FieldResolver.Resolve(fields, map.RefinementNotes, "refinementnotes", "refinement", "groomingnotes")),
            DevelopmentNotes = Clean(FieldResolver.Resolve(fields, map.DevelopmentNotes, "developmentnotes", "devnotes", "implementationnotes")),
            TestingNotes = Clean(FieldResolver.Resolve(fields, map.TestingNotes, "testingnotes", "testnotes", "qanotes")),

            Discussion = await GetCommentsAsync(id, ct)
        };
    }

    private async Task<IReadOnlyList<DiscussionComment>> GetCommentsAsync(int id, CancellationToken ct)
    {
        // Comments still live behind a -preview flavour of the API version.
        var url = $"{Org}/{Project}/_apis/wit/workItems/{id}/comments?api-version={Api}-preview.4&$top=200";

        try
        {
            using var doc = await GetJsonAsync(url, ct);

            var comments = new List<DiscussionComment>();
            if (!doc.RootElement.TryGetProperty("comments", out var list))
                return comments;

            foreach (var comment in list.EnumerateArray())
            {
                var author = comment.TryGetProperty("createdBy", out var by)
                    ? FieldResolver.AsString(by)
                    : "Unknown";

                var created = ReadDate(comment, "createdDate") ?? DateTime.MinValue;
                var text = Clean(comment.TryGetProperty("text", out var t) ? t.GetString() : null);

                if (!string.IsNullOrWhiteSpace(text))
                    comments.Add(new DiscussionComment(author, created, text));
            }

            return comments.OrderBy(c => c.CreatedDate).ToList();
        }
        catch (HttpRequestException ex)
        {
            // A missing discussion should never fail the whole export.
            _log.LogWarning(ex, "Could not read comments for work item {Id}", id);
            return [];
        }
    }

    private string BuildWebUrl(int id)
        => $"{_options.BaseUrl.TrimEnd('/')}/{_options.Organization}/{_options.Project}/_workitems/edit/{id}";

    private async Task<JsonDocument> GetJsonAsync(string url, CancellationToken ct)
    {
        using var response = await _http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
        await EnsureSuccessAsync(response, url, ct);

        return await JsonDocument.ParseAsync(
            await response.Content.ReadAsStreamAsync(ct), cancellationToken: ct);
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response, string url, CancellationToken ct)
    {
        if (response.IsSuccessStatusCode)
        {
            // A PAT that is wrong or expired gets redirected to a sign-in page, which
            // comes back as 200 text/html rather than 401. Catch that explicitly.
            var mediaType = response.Content.Headers.ContentType?.MediaType;
            if (mediaType is not null && mediaType.Contains("html", StringComparison.OrdinalIgnoreCase))
            {
                throw new HttpRequestException(
                    "Azure DevOps returned an HTML sign-in page. The PAT is probably missing, expired, "
                    + "or lacks 'Work Items (Read)' scope for this organisation.");
            }

            return;
        }

        var body = await response.Content.ReadAsStringAsync(ct);
        if (body.Length > 600) body = body[..600];

        throw new HttpRequestException(
            $"Azure DevOps request failed ({(int)response.StatusCode} {response.ReasonPhrase}).\nURL: {url}\n{body}");
    }

    private static IReadOnlyDictionary<string, JsonElement> ReadFields(JsonElement workItem)
    {
        if (!workItem.TryGetProperty("fields", out var fields))
            return new Dictionary<string, JsonElement>();

        var map = new Dictionary<string, JsonElement>(StringComparer.OrdinalIgnoreCase);
        foreach (var field in fields.EnumerateObject())
            map[field.Name] = field.Value;

        return map;
    }

    private static DateTime? ReadDate(JsonElement element, string propertyName)
        => element.TryGetProperty(propertyName, out var value) && value.ValueKind == JsonValueKind.String
            && DateTime.TryParse(value.GetString(), out var parsed)
                ? parsed
                : null;

    private static string Clean(string? html) => HtmlText.ToPlainText(html);

    /// <summary>WIQL escapes a single quote by doubling it.</summary>
    private static string Escape(string value) => value.Replace("'", "''");
}
