using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using SkyWorkItems.Configuration;
using SkyWorkItems.Models;
using SkyWorkItems.Services.Export;

namespace SkyWorkItems.Services.Ai;

/// <summary>
/// Semantic Kernel chat over the selected work item. The kernel is built lazily so a
/// missing or wrong AI key never stops the DevOps side of the app from working.
/// </summary>
public sealed class SemanticKernelStoryChatService : IStoryChatService
{
    private readonly AiOptions _options;
    private readonly ILogger<SemanticKernelStoryChatService> _log;
    private readonly Lazy<IChatCompletionService> _chat;

    public SemanticKernelStoryChatService(
        IOptions<AppSettings> settings,
        ILogger<SemanticKernelStoryChatService> log)
    {
        _options = settings.Value.Ai;
        _log = log;
        _chat = new Lazy<IChatCompletionService>(BuildChatService, isThreadSafe: true);
    }

    public string AgentName => string.IsNullOrWhiteSpace(_options.AgentName)
        ? "Agent"
        : _options.AgentName;

    public bool IsConfigured =>
        _options.Enabled
        && !string.IsNullOrWhiteSpace(_options.Endpoint)
        && !string.IsNullOrWhiteSpace(_options.ApiKey)
        && !_options.ApiKey.StartsWith("REPLACE_WITH", StringComparison.OrdinalIgnoreCase);

    public async Task<string> AskAsync(
        WorkItemDetail story,
        IReadOnlyList<ChatTurn> history,
        string question,
        CancellationToken ct = default)
    {
        if (!IsConfigured)
            throw new InvalidOperationException("The AI section of appsettings.json is not filled in.");

        var chatHistory = new ChatHistory(BuildSystemPrompt(story));

        foreach (var turn in history)
        {
            if (turn.IsUser)
                chatHistory.AddUserMessage(turn.Content);
            else
                chatHistory.AddAssistantMessage(turn.Content);
        }

        chatHistory.AddUserMessage(question);

        var settings = new OpenAIPromptExecutionSettings
        {
            Temperature = 0.2,
            MaxTokens = 1200
        };

        _log.LogInformation("Asking {Agent} about work item {Id}", AgentName, story.Id);

        var response = await _chat.Value.GetChatMessageContentAsync(chatHistory, settings, cancellationToken: ct);
        return response.Content ?? string.Empty;
    }

    private string BuildSystemPrompt(WorkItemDetail story)
    {
        var instruction = string.IsNullOrWhiteSpace(_options.SystemPrompt)
            ? $"You are {AgentName}, a requirements analyst. Answer only from the work item below. "
              + "If the work item does not cover something, say so rather than guessing."
            : _options.SystemPrompt;

        return $"""
            {instruction}

            ----- WORK ITEM -----
            {WorkItemMarkdown.Build(story)}
            ----- END WORK ITEM -----
            """;
    }

    private IChatCompletionService BuildChatService()
    {
        var builder = Kernel.CreateBuilder();
        builder.AddAzureOpenAIChatCompletion(
            deploymentName: _options.DeploymentName,
            endpoint: _options.Endpoint,
            apiKey: _options.ApiKey);

        return builder.Build().GetRequiredService<IChatCompletionService>();
    }
}
