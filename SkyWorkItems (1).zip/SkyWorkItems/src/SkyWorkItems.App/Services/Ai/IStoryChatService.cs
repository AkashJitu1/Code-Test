using SkyWorkItems.Models;

namespace SkyWorkItems.Services.Ai;

/// <summary>
/// Chat grounded in one work item. The ViewModel depends on this, not on Semantic
/// Kernel, so the backing agent can be swapped without touching the UI (DIP).
/// </summary>
public interface IStoryChatService
{
    string AgentName { get; }

    bool IsConfigured { get; }

    Task<string> AskAsync(
        WorkItemDetail story,
        IReadOnlyList<ChatTurn> history,
        string question,
        CancellationToken ct = default);
}
