using SkyWorkItems.Models;

namespace SkyWorkItems.Services.Export;

/// <summary>
/// One implementation per output format. Adding (say) DOCX later means adding a class
/// and registering it — no existing code changes (OCP).
/// </summary>
public interface IWorkItemExporter
{
    /// <summary>Matches the Export:Format setting: "Markdown" or "Pdf".</summary>
    string Format { get; }

    /// <summary>Writes one file and returns its full path.</summary>
    Task<string> ExportAsync(WorkItemDetail item, string outputDirectory, CancellationToken ct = default);
}
