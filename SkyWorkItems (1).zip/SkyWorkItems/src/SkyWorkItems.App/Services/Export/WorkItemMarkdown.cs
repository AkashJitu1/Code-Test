using System.Text;
using SkyWorkItems.Models;

namespace SkyWorkItems.Services.Export;

/// <summary>
/// Single source of truth for the document body. Both the Markdown exporter and the
/// Semantic Kernel prompt use it, so the agent sees exactly what Copilot will see.
/// </summary>
public static class WorkItemMarkdown
{
    public static string Build(WorkItemDetail item)
    {
        var sb = new StringBuilder();

        sb.AppendLine($"# [{item.WorkItemType} {item.Id}] {item.Title}").AppendLine();
        sb.AppendLine($"- **Work item:** {item.Id}");
        sb.AppendLine($"- **Type:** {Or(item.WorkItemType)}");
        sb.AppendLine($"- **State:** {Or(item.State)}");
        sb.AppendLine($"- **Assigned to:** {Or(item.AssignedTo)}");
        sb.AppendLine($"- **Iteration:** {Or(item.IterationPath)}");
        sb.AppendLine($"- **Area:** {Or(item.AreaPath)}");

        if (!string.IsNullOrWhiteSpace(item.Tags))
            sb.AppendLine($"- **Tags:** {item.Tags}");

        sb.AppendLine($"- **Link:** {item.WebUrl}").AppendLine();

        Section(sb, "Description", item.Description);
        Section(sb, "Acceptance Criteria", item.AcceptanceCriteria);
        Section(sb, "Refinement Notes", item.RefinementNotes);
        Section(sb, "Development Notes", item.DevelopmentNotes);
        Section(sb, "Testing Notes", item.TestingNotes);

        sb.AppendLine("## Discussion").AppendLine();
        if (item.Discussion.Count == 0)
        {
            sb.AppendLine("_No comments._").AppendLine();
        }
        else
        {
            foreach (var comment in item.Discussion)
            {
                sb.AppendLine($"### {comment.Author} — {comment.CreatedDate:dd MMM yyyy HH:mm}").AppendLine();
                sb.AppendLine(comment.Text).AppendLine();
            }
        }

        return sb.ToString();
    }

    private static void Section(StringBuilder sb, string heading, string body)
    {
        sb.AppendLine($"## {heading}").AppendLine();
        sb.AppendLine(string.IsNullOrWhiteSpace(body) ? "_Not provided._" : body).AppendLine();
    }

    private static string Or(string value) => string.IsNullOrWhiteSpace(value) ? "—" : value;
}
