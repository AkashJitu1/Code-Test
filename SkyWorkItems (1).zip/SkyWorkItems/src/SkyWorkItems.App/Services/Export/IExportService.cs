using SkyWorkItems.Models;

namespace SkyWorkItems.Services.Export;

public interface IExportService
{
    /// <summary>Fetches details for each id and writes the configured formats.</summary>
    Task<ExportResult> ExportAsync(
        IReadOnlyList<int> ids,
        string format,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken ct = default);
}

public sealed record ExportResult(IReadOnlyList<string> Files, IReadOnlyList<string> Failures)
{
    public string OutputDirectory { get; init; } = string.Empty;
}
