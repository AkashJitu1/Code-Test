using System.Text;
using SkyWorkItems.Common;
using SkyWorkItems.Models;

namespace SkyWorkItems.Services.Export;

public sealed class MarkdownWorkItemExporter : IWorkItemExporter
{
    public string Format => "Markdown";

    public async Task<string> ExportAsync(WorkItemDetail item, string outputDirectory, CancellationToken ct = default)
    {
        Directory.CreateDirectory(outputDirectory);

        var path = Path.Combine(outputDirectory, FileNames.Safe(item.Id, item.Title) + ".md");
        await File.WriteAllTextAsync(path, WorkItemMarkdown.Build(item), Encoding.UTF8, ct);
        return path;
    }
}
