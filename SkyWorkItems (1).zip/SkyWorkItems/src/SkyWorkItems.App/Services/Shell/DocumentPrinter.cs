using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace SkyWorkItems.Services.Shell;

/// <summary>One printable block: a bold heading followed by a body paragraph.</summary>
public sealed record PrintSection(string Heading, string Body, bool Monospaced = false);

/// <summary>
/// Printing and clipboard access. Both are UI-thread concerns that would otherwise
/// drag <c>System.Windows</c> types into the view models, so they sit behind this
/// interface and get faked in tests.
/// </summary>
public interface IDocumentPrinter
{
    /// <summary>
    /// Shows the print dialog and prints the sections as a flow document.
    /// Returns false when the user cancels.
    /// </summary>
    bool Print(string title, IReadOnlyList<PrintSection> sections);

    /// <summary>Copies text to the clipboard, swallowing the transient COM failures it can throw.</summary>
    void CopyToClipboard(string text);
}

public sealed class WpfDocumentPrinter : IDocumentPrinter
{
    public bool Print(string title, IReadOnlyList<PrintSection> sections)
    {
        var dialog = new PrintDialog();
        if (dialog.ShowDialog() != true)
            return false;

        var document = BuildDocument(title, sections);

        // The paginator needs real page metrics before it can lay anything out, and the
        // only reliable source is the printer the user just picked in the dialog.
        document.PageWidth = dialog.PrintableAreaWidth;
        document.PageHeight = dialog.PrintableAreaHeight;
        document.PagePadding = new Thickness(48);
        document.ColumnWidth = dialog.PrintableAreaWidth; // one column, not newspaper columns

        IDocumentPaginatorSource paginator = document;
        dialog.PrintDocument(paginator.DocumentPaginator, title);
        return true;
    }

    public void CopyToClipboard(string text)
    {
        if (string.IsNullOrEmpty(text))
            return;

        try
        {
            Clipboard.SetText(text);
        }
        catch (Exception)
        {
            // The Windows clipboard is a shared, lockable resource: another process can
            // hold it open and make SetText throw. Losing a copy is not worth a crash.
        }
    }

    private static FlowDocument BuildDocument(string title, IReadOnlyList<PrintSection> sections)
    {
        var document = new FlowDocument
        {
            FontFamily = new FontFamily("Segoe UI"),
            FontSize = 12,
            Foreground = Brushes.Black
        };

        document.Blocks.Add(new Paragraph(new Run(title))
        {
            FontSize = 19,
            FontWeight = FontWeights.Bold,
            Margin = new Thickness(0, 0, 0, 4)
        });

        document.Blocks.Add(new Paragraph(new Run($"Printed {DateTime.Now:dd MMM yyyy HH:mm}"))
        {
            FontSize = 10,
            Foreground = Brushes.Gray,
            Margin = new Thickness(0, 0, 0, 16)
        });

        foreach (var section in sections)
        {
            if (!string.IsNullOrWhiteSpace(section.Heading))
            {
                document.Blocks.Add(new Paragraph(new Run(section.Heading))
                {
                    FontSize = 13,
                    FontWeight = FontWeights.SemiBold,
                    Margin = new Thickness(0, 10, 0, 2)
                });
            }

            var body = new Paragraph(new Run(section.Body ?? string.Empty))
            {
                Margin = new Thickness(0, 0, 0, 8)
            };

            if (section.Monospaced)
            {
                body.FontFamily = new FontFamily("Consolas");
                body.FontSize = 10.5;
            }

            document.Blocks.Add(body);
        }

        return document;
    }
}
