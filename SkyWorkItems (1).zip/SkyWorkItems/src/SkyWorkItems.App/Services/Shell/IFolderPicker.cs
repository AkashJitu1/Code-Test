namespace SkyWorkItems.Services.Shell;

/// <summary>Keeps the file dialog out of the ViewModel so it stays testable.</summary>
public interface IFolderPicker
{
    string? Pick(string title, string? initialDirectory = null);
}
