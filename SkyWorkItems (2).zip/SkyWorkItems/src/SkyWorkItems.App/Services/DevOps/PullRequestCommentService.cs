// -----------------------------------------------------------------------------
//  PullRequestCommentService.cs
//
//  Self-contained service that pulls pull-request review comments out of Azure
//  DevOps and writes them to a single Markdown file, including the source lines
//  a reviewer highlighted when leaving the comment.
//
//  Everything it needs lives in this one file: options, filter, result models,
//  the abstraction, the REST implementation and the Markdown writer. Drop it into
//  any project; the only external requirement is a PAT-authenticated HttpClient.
//
//  DI registration (Microsoft.Extensions.DependencyInjection):
//
//      services.AddHttpClient<IPullRequestCommentService, PullRequestCommentService>(
//          (sp, http) =>
//          {
//              var o = sp.GetRequiredService<IOptions<AppSettings>>().Value.AzureDevOps;
//              http.BaseAddress = new Uri(o.BaseUrl.TrimEnd('/') + "/");
//              http.Timeout = TimeSpan.FromSeconds(120);
//              http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
//                  "Basic",
//                  Convert.ToBase64String(Encoding.ASCII.GetBytes(":" + o.PersonalAccessToken)));
//          });
//
//      services.AddSingleton(sp =>
//      {
//          var o = sp.GetRequiredService<IOptions<AppSettings>>().Value.AzureDevOps;
//          return new PullRequestCommentOptions
//          {
//              BaseUrl = o.BaseUrl,
//              Organization = o.Organization,
//              Project = o.Project,
//              ApiVersion = o.ApiVersion
//          };
//      });
//
//  PAT scopes required: Code (Read).
// -----------------------------------------------------------------------------

using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using SkyWorkItems.Models;

namespace SkyWorkItems.Services.DevOps;

// =============================================================================
//  1. Options and filter
// =============================================================================

/// <summary>
/// Connection details the service needs to build REST URLs. Kept separate from the
/// app-wide settings class so this file can be reused in another project unchanged.
/// </summary>
public sealed class PullRequestCommentOptions
{
    public string BaseUrl { get; init; } = "https://dev.azure.com";
    public string Organization { get; init; } = string.Empty;
    public string Project { get; init; } = string.Empty;
    public string ApiVersion { get; init; } = "7.1";
}

/// <summary>
/// Everything the caller can narrow the search by. All properties are optional;
/// an empty filter returns recent comments across every repository in the project.
/// </summary>
public sealed class PullRequestCommentFilter
{
    /// <summary>
    /// Team project to search. Blank falls back to
    /// <see cref="PullRequestCommentOptions.Project"/>, so a caller that only ever uses
    /// one project can ignore this.
    /// </summary>
    public string Project { get; set; } = string.Empty;

    /// <summary>Earliest <b>comment</b> date to keep (inclusive). Null means no lower bound.</summary>
    public DateTimeOffset? FromDate { get; set; }

    /// <summary>Latest <b>comment</b> date to keep (inclusive). Null means no upper bound.</summary>
    public DateTimeOffset? ToDate { get; set; }

    /// <summary>
    /// Reviewer names to keep. Matched case-insensitively as a substring against both
    /// the display name ("Akash Kumar") and the sign-in address
    /// ("akash.kumar@example.com"), so a partial name or just the alias both work.
    /// Empty means every reviewer.
    /// </summary>
    public IReadOnlyList<string> ReviewerNames { get; set; } = [];

    /// <summary>Repository names to search. Empty means every repository in the project.</summary>
    public IReadOnlyList<string> RepositoryNames { get; set; } = [];

    /// <summary>Only look at pull requests created on or after this date. Applied server-side.</summary>
    public DateTimeOffset? PullRequestCreatedFrom { get; set; }

    /// <summary>Only look at pull requests created on or before this date. Applied server-side.</summary>
    public DateTimeOffset? PullRequestCreatedTo { get; set; }

    /// <summary>"active", "completed", "abandoned" or "all".</summary>
    public string PullRequestStatus { get; set; } = "all";

    /// <summary>Optional target branch, e.g. "refs/heads/main" or just "main".</summary>
    public string? TargetBranch { get; set; }

    /// <summary>
    /// Azure DevOps posts its own bookkeeping messages ("X voted 10", "build succeeded")
    /// into the same thread list. They are excluded by default.
    /// </summary>
    public bool IncludeSystemComments { get; set; }

    /// <summary>When false, only the first comment of each thread is returned.</summary>
    public bool IncludeReplies { get; set; } = true;

    /// <summary>Fetch the highlighted source lines for file-anchored comments.</summary>
    public bool IncludeCodeSnippets { get; set; } = true;

    /// <summary>Extra lines of context shown above and below the highlighted range.</summary>
    public int CodeContextLines { get; set; } = 2;

    /// <summary>Safety valve so an unfiltered run cannot page through thousands of PRs.</summary>
    public int MaxPullRequests { get; set; } = 300;

    /// <summary>Human-readable description of the active filter, used in the report header.</summary>
    public string Describe()
    {
        var parts = new List<string>
        {
            FromDate is null && ToDate is null
                ? "Comment date: any"
                : $"Comment date: {Format(FromDate, "beginning")} to {Format(ToDate, "today")}",
            ReviewerNames.Count == 0
                ? "Reviewers: all"
                : "Reviewers: " + string.Join(", ", ReviewerNames),
            RepositoryNames.Count == 0
                ? "Repositories: all in project"
                : "Repositories: " + string.Join(", ", RepositoryNames),
            $"PR status: {PullRequestStatus}"
        };

        if (!string.IsNullOrWhiteSpace(Project))
            parts.Insert(0, $"Project: {Project}");

        if (!string.IsNullOrWhiteSpace(TargetBranch))
            parts.Add($"Target branch: {TargetBranch}");

        if (PullRequestCreatedFrom is not null || PullRequestCreatedTo is not null)
            parts.Add($"PR created: {Format(PullRequestCreatedFrom, "beginning")} to {Format(PullRequestCreatedTo, "today")}");

        if (!IncludeReplies) parts.Add("Replies excluded");
        if (IncludeSystemComments) parts.Add("System messages included");

        return string.Join("\n", parts.Select(p => "- " + p));

        static string Format(DateTimeOffset? value, string fallback)
            => value?.ToString("dd MMM yyyy") ?? fallback;
    }
}

// =============================================================================
//  2. Result models
// =============================================================================

/// <summary>One reviewer comment, flattened with the pull request context around it.</summary>
public sealed record ReviewComment
{
    // --- pull request ---
    public required int PullRequestId { get; init; }
    public required string PullRequestTitle { get; init; }
    public required string RepositoryName { get; init; }
    public required DateTimeOffset PullRequestCreatedDate { get; init; }
    public required string PullRequestUrl { get; init; }
    public string PullRequestAuthor { get; init; } = string.Empty;
    public string PullRequestStatus { get; init; } = string.Empty;

    // --- comment ---
    public required int ThreadId { get; init; }
    public required int CommentId { get; init; }
    public required string ReviewerName { get; init; }
    public string ReviewerEmail { get; init; } = string.Empty;
    public required DateTimeOffset CommentDate { get; init; }
    public required string Content { get; init; }
    public string ThreadStatus { get; init; } = string.Empty;

    /// <summary>True when this comment is a reply inside an existing thread.</summary>
    public bool IsReply { get; init; }

    // --- code anchor (null for PR-level "overview" comments) ---
    public string? FilePath { get; init; }
    public int? StartLine { get; init; }
    public int? EndLine { get; init; }

    /// <summary>
    /// True when the comment is anchored to the left (base) side of the diff, i.e. to
    /// lines the PR removed rather than lines it added.
    /// </summary>
    public bool IsLeftSide { get; init; }

    /// <summary>The highlighted source lines plus context. Null when unavailable.</summary>
    public string? CodeSnippet { get; init; }

    /// <summary>Markdown fence language inferred from the file extension.</summary>
    public string? Language { get; init; }

    /// <summary>Deep link that opens the PR's Files tab scrolled to this thread.</summary>
    public string CommentUrl => $"{PullRequestUrl}?_a=files&discussionId={ThreadId}";

    /// <summary>"src/Foo.cs (lines 20-24)" or "PR overview" when there is no file anchor.</summary>
    public string LocationCaption
    {
        get
        {
            if (string.IsNullOrWhiteSpace(FilePath))
                return "PR overview (not anchored to a file)";

            var side = IsLeftSide ? " — removed lines" : string.Empty;

            return StartLine switch
            {
                null => $"{FilePath}{side}",
                _ when EndLine is null || EndLine == StartLine => $"{FilePath} (line {StartLine}){side}",
                _ => $"{FilePath} (lines {StartLine}-{EndLine}){side}"
            };
        }
    }
}

// =============================================================================
//  3. Abstraction
// =============================================================================

/// <summary>
/// Reads pull-request review comments and renders them as Markdown. Two members only,
/// so a fake implementation for tests is a few lines (ISP).
/// </summary>
public interface IPullRequestCommentService
{
    /// <summary>Team projects the PAT can see. Populates the project picker.</summary>
    Task<IReadOnlyList<ProjectRef>> GetProjectsAsync(CancellationToken ct = default);

    /// <summary>Git repositories inside a project. Populates the repository picker.</summary>
    Task<IReadOnlyList<RepositoryRef>> GetRepositoriesAsync(string project, CancellationToken ct = default);

    /// <summary>Fetches every comment matching <paramref name="filter"/>, newest PR first.</summary>
    Task<IReadOnlyList<ReviewComment>> GetCommentsAsync(
        PullRequestCommentFilter filter,
        IProgress<string>? progress = null,
        CancellationToken ct = default);

    /// <summary>Writes one Markdown report and returns its full path.</summary>
    Task<string> ExportMarkdownAsync(
        IReadOnlyList<ReviewComment> comments,
        PullRequestCommentFilter filter,
        string outputDirectory,
        string? fileName = null,
        CancellationToken ct = default);
}

// =============================================================================
//  4. Implementation
// =============================================================================

/// <summary>
/// Azure DevOps Git REST API (7.1) implementation.
///
/// Call sequence:
///   repositories  -> pull requests (paged) -> threads per PR -> file content per anchor
///
/// The last step is the expensive one, so file contents are cached per
/// (repository, commit, path) for the lifetime of a single call.
/// </summary>
public sealed class PullRequestCommentService : IPullRequestCommentService
{
    private const int PageSize = 100;              // $top ceiling that the PR list API honours
    private const int MaxSnippetLines = 40;        // guard against a reviewer selecting a whole file

    private readonly HttpClient _http;
    private readonly PullRequestCommentOptions _options;
    private readonly ILogger<PullRequestCommentService> _log;

    public PullRequestCommentService(
        HttpClient http,
        PullRequestCommentOptions options,
        ILogger<PullRequestCommentService> log)
    {
        _http = http;
        _options = options;
        _log = log;
    }

    private string Org => Uri.EscapeDataString(_options.Organization);
    private string Api => _options.ApiVersion;

    /// <summary>Project and repository names can contain spaces; escape every segment.</summary>
    private static string Enc(string value) => Uri.EscapeDataString(value ?? string.Empty);

    /// <summary>Filter project wins; the configured project is only the default.</summary>
    private string ProjectFor(PullRequestCommentFilter filter)
        => string.IsNullOrWhiteSpace(filter.Project) ? _options.Project : filter.Project;

    public async Task<IReadOnlyList<ProjectRef>> GetProjectsAsync(CancellationToken ct = default)
    {
        var url = $"{Org}/_apis/projects?api-version={Api}&$top=500&stateFilter=wellFormed";
        using var doc = await GetJsonAsync(url, ct);

        var projects = new List<ProjectRef>();
        foreach (var project in doc.RootElement.GetProperty("value").EnumerateArray())
        {
            projects.Add(new ProjectRef(
                project.GetProperty("id").GetString() ?? string.Empty,
                project.GetProperty("name").GetString() ?? string.Empty));
        }

        return projects.OrderBy(p => p.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }

    // -------------------------------------------------------------------------
    //  4.1 Public entry point
    // -------------------------------------------------------------------------

    public async Task<IReadOnlyList<ReviewComment>> GetCommentsAsync(
        PullRequestCommentFilter filter,
        IProgress<string>? progress = null,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(filter);

        // Normalise the date bounds once. ToDate is treated as "end of that day" when the
        // caller passes a bare date, otherwise a comment posted at 16:40 on the last day
        // of the range would be dropped.
        var from = filter.FromDate;
        var to = NormaliseUpperBound(filter.ToDate);

        // Per-call cache: many comments in one PR usually point at the same few files.
        var fileCache = new Dictionary<string, string[]?>(StringComparer.Ordinal);

        var results = new List<ReviewComment>();

        var project = ProjectFor(filter);
        if (string.IsNullOrWhiteSpace(project))
            throw new InvalidOperationException("No project selected.");

        var repositories = await GetRepositoriesAsync(project, filter.RepositoryNames, ct);
        if (repositories.Count == 0)
        {
            _log.LogWarning("No repositories matched the filter.");
            return results;
        }

        foreach (var repo in repositories)
        {
            ct.ThrowIfCancellationRequested();
            progress?.Report($"Scanning repository {repo.Name}…");

            var pullRequests = await GetPullRequestsAsync(project, repo, filter, ct);
            _log.LogInformation("{Repo}: {Count} pull request(s) to inspect", repo.Name, pullRequests.Count);

            var index = 0;
            foreach (var pr in pullRequests)
            {
                ct.ThrowIfCancellationRequested();
                index++;
                progress?.Report($"{repo.Name}: PR {index}/{pullRequests.Count} (#{pr.Id})…");

                var comments = await GetThreadCommentsAsync(project, repo, pr, filter, from, to, fileCache, ct);
                results.AddRange(comments);
            }
        }

        // Newest pull request first, then chronological within the PR so a thread reads
        // top-to-bottom in the report.
        return results
            .OrderByDescending(c => c.PullRequestCreatedDate)
            .ThenByDescending(c => c.PullRequestId)
            .ThenBy(c => c.ThreadId)
            .ThenBy(c => c.CommentDate)
            .ToList();
    }

    // -------------------------------------------------------------------------
    //  4.2 Repositories
    // -------------------------------------------------------------------------

    public Task<IReadOnlyList<RepositoryRef>> GetRepositoriesAsync(
        string project, CancellationToken ct = default)
        => GetRepositoriesAsync(project, [], ct);

    private async Task<IReadOnlyList<RepositoryRef>> GetRepositoriesAsync(
        string project, IReadOnlyList<string> wanted, CancellationToken ct)
    {
        var url = $"{Org}/{Enc(project)}/_apis/git/repositories?api-version={Api}";
        using var doc = await GetJsonAsync(url, ct);

        var all = new List<RepositoryRef>();
        foreach (var repo in doc.RootElement.GetProperty("value").EnumerateArray())
        {
            all.Add(new RepositoryRef(
                repo.GetProperty("id").GetString() ?? string.Empty,
                repo.GetProperty("name").GetString() ?? string.Empty));
        }

        if (wanted.Count == 0)
            return all;

        // Match on name, case-insensitively, so callers do not have to know repo GUIDs.
        return all
            .Where(r => wanted.Any(w => string.Equals(w, r.Name, StringComparison.OrdinalIgnoreCase)))
            .ToList();
    }

    // -------------------------------------------------------------------------
    //  4.3 Pull requests
    // -------------------------------------------------------------------------

    /// <summary>
    /// Pages through the PR list.
    ///
    /// Two things worth knowing:
    ///
    /// 1. The API's time range (<c>searchCriteria.minTime</c>/<c>maxTime</c>) filters on the
    ///    <i>pull request</i>, not on its comments. A PR opened in January can still receive a
    ///    comment in September, so the comment date range is deliberately NOT pushed down to
    ///    this call — it is applied per comment later. Only an explicit
    ///    <see cref="PullRequestCommentFilter.PullRequestCreatedFrom"/> is sent server-side.
    ///
    /// 2. Results come back newest-first by creation date, which lets us stop paging as soon
    ///    as we drop below <c>PullRequestCreatedFrom</c> instead of walking the whole history.
    /// </summary>
    private async Task<IReadOnlyList<PullRequestRef>> GetPullRequestsAsync(
        string project, RepositoryRef repo, PullRequestCommentFilter filter, CancellationToken ct)
    {
        var pullRequests = new List<PullRequestRef>();
        var skip = 0;

        while (pullRequests.Count < filter.MaxPullRequests)
        {
            ct.ThrowIfCancellationRequested();

            var top = Math.Min(PageSize, filter.MaxPullRequests - pullRequests.Count);
            var query = new StringBuilder()
                .Append($"{Org}/{Enc(project)}/_apis/git/repositories/{Enc(repo.Id)}/pullrequests")
                .Append($"?api-version={Api}")
                .Append($"&searchCriteria.status={Uri.EscapeDataString(filter.PullRequestStatus)}")
                .Append($"&$top={top}&$skip={skip}");

            if (!string.IsNullOrWhiteSpace(filter.TargetBranch))
                query.Append($"&searchCriteria.targetRefName={Uri.EscapeDataString(ToRefName(filter.TargetBranch))}");

            if (filter.PullRequestCreatedFrom is { } createdFrom)
            {
                query.Append("&searchCriteria.queryTimeRangeType=created");
                query.Append($"&searchCriteria.minTime={Uri.EscapeDataString(createdFrom.UtcDateTime.ToString("O"))}");
            }

            if (filter.PullRequestCreatedTo is { } createdTo)
            {
                query.Append("&searchCriteria.queryTimeRangeType=created");
                query.Append($"&searchCriteria.maxTime={Uri.EscapeDataString(NormaliseUpperBound(createdTo)!.Value.UtcDateTime.ToString("O"))}");
            }

            using var doc = await GetJsonAsync(query.ToString(), ct);

            var pageCount = 0;
            var reachedLowerBound = false;

            foreach (var item in doc.RootElement.GetProperty("value").EnumerateArray())
            {
                pageCount++;

                var created = ReadDate(item, "creationDate") ?? DateTimeOffset.MinValue;

                // Defensive client-side re-check: older API versions ignore the time range
                // parameters instead of failing, which would silently widen the result set.
                if (filter.PullRequestCreatedFrom is { } lower && created < lower)
                {
                    reachedLowerBound = true;
                    continue;
                }

                if (filter.PullRequestCreatedTo is { } upper && created > NormaliseUpperBound(upper))
                    continue;

                var id = item.GetProperty("pullRequestId").GetInt32();

                pullRequests.Add(new PullRequestRef(
                    Id: id,
                    Title: ReadString(item, "title"),
                    Status: ReadString(item, "status"),
                    Author: ReadIdentity(item, "createdBy").Name,
                    CreatedDate: created,
                    SourceCommitId: ReadNestedString(item, "lastMergeSourceCommit", "commitId"),
                    TargetCommitId: ReadNestedString(item, "lastMergeTargetCommit", "commitId"),
                    Url: BuildPullRequestUrl(project, repo.Name, id),
                    Repository: repo));
            }

            // Stop when the server ran out of results, or when we have paged past the
            // creation-date floor (results are ordered newest first).
            if (pageCount < top || reachedLowerBound)
                break;

            skip += pageCount;
        }

        return pullRequests;
    }

    // -------------------------------------------------------------------------
    //  4.4 Threads and comments
    // -------------------------------------------------------------------------

    /// <summary>
    /// Reads every discussion thread on a PR and flattens it into <see cref="ReviewComment"/>s.
    ///
    /// A thread carries the code anchor (file path and line range); the individual comments
    /// carry the author and text. A thread with no <c>threadContext</c> is a PR-level comment.
    /// </summary>
    private async Task<List<ReviewComment>> GetThreadCommentsAsync(
        string project,
        RepositoryRef repo,
        PullRequestRef pr,
        PullRequestCommentFilter filter,
        DateTimeOffset? from,
        DateTimeOffset? to,
        Dictionary<string, string[]?> fileCache,
        CancellationToken ct)
    {
        var url = $"{Org}/{Enc(project)}/_apis/git/repositories/{Enc(repo.Id)}"
                + $"/pullRequests/{pr.Id}/threads?api-version={Api}";

        JsonDocument doc;
        try
        {
            doc = await GetJsonAsync(url, ct);
        }
        catch (HttpRequestException ex)
        {
            // One unreadable PR (permissions, deleted fork) must not abort the whole run.
            _log.LogWarning(ex, "Could not read threads for PR {PullRequestId}", pr.Id);
            return [];
        }

        using (doc)
        {
            var results = new List<ReviewComment>();

            foreach (var thread in doc.RootElement.GetProperty("value").EnumerateArray())
            {
                ct.ThrowIfCancellationRequested();

                if (ReadBool(thread, "isDeleted"))
                    continue;

                var threadId = thread.GetProperty("id").GetInt32();
                var threadStatus = ReadString(thread, "status");
                var anchor = ReadAnchor(thread);

                // The snippet is fetched lazily and only once per thread, because every
                // comment in the thread shares the same anchor.
                string? snippet = null;
                var snippetResolved = false;

                if (!thread.TryGetProperty("comments", out var comments)
                    || comments.ValueKind != JsonValueKind.Array)
                {
                    continue;
                }

                foreach (var comment in comments.EnumerateArray())
                {
                    if (ReadBool(comment, "isDeleted"))
                        continue;

                    var commentType = ReadString(comment, "commentType");
                    if (!filter.IncludeSystemComments
                        && string.Equals(commentType, "system", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    // parentCommentId is 0 (or absent) on the first comment of a thread.
                    var parentId = ReadInt(comment, "parentCommentId") ?? 0;
                    var isReply = parentId > 0;
                    if (isReply && !filter.IncludeReplies)
                        continue;

                    var author = ReadIdentity(comment, "author");
                    if (!MatchesReviewer(author, filter.ReviewerNames))
                        continue;

                    var published = ReadDate(comment, "publishedDate")
                                    ?? ReadDate(thread, "publishedDate")
                                    ?? DateTimeOffset.MinValue;

                    if (from is not null && published < from) continue;
                    if (to is not null && published > to) continue;

                    var content = (ReadString(comment, "content") ?? string.Empty).Trim();
                    if (content.Length == 0)
                        continue;

                    if (!snippetResolved)
                    {
                        snippetResolved = true;
                        snippet = filter.IncludeCodeSnippets && anchor is not null
                            ? await GetSnippetAsync(project, repo, pr, anchor, filter.CodeContextLines, fileCache, ct)
                            : null;
                    }

                    results.Add(new ReviewComment
                    {
                        PullRequestId = pr.Id,
                        PullRequestTitle = pr.Title,
                        RepositoryName = repo.Name,
                        PullRequestCreatedDate = pr.CreatedDate,
                        PullRequestUrl = pr.Url,
                        PullRequestAuthor = pr.Author,
                        PullRequestStatus = pr.Status,

                        ThreadId = threadId,
                        CommentId = ReadInt(comment, "id") ?? 0,
                        ReviewerName = author.Name,
                        ReviewerEmail = author.Email,
                        CommentDate = published,
                        Content = content,
                        ThreadStatus = threadStatus,
                        IsReply = isReply,

                        FilePath = anchor?.FilePath,
                        StartLine = anchor?.StartLine,
                        EndLine = anchor?.EndLine,
                        IsLeftSide = anchor?.IsLeftSide ?? false,
                        CodeSnippet = snippet,
                        Language = anchor is null ? null : LanguageFor(anchor.FilePath)
                    });
                }
            }

            return results;
        }
    }

    /// <summary>
    /// Case-insensitive substring match against the display name and the sign-in address.
    /// "akash", "Akash Kumar" and "akash.kumar@" all match the same person.
    /// </summary>
    private static bool MatchesReviewer(Identity author, IReadOnlyList<string> wanted)
    {
        if (wanted.Count == 0)
            return true;

        foreach (var candidate in wanted)
        {
            if (string.IsNullOrWhiteSpace(candidate))
                continue;

            var needle = candidate.Trim();

            if (author.Name.Contains(needle, StringComparison.OrdinalIgnoreCase)
                || author.Email.Contains(needle, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }

    // -------------------------------------------------------------------------
    //  4.5 Code snippet resolution
    // -------------------------------------------------------------------------

    /// <summary>
    /// Reads the highlighted source lines.
    ///
    /// The diff has two sides. A comment on an added or changed line is anchored to the
    /// <b>right</b> side, whose content lives in the PR's source commit. A comment on a
    /// line the PR deleted is anchored to the <b>left</b> side, which only exists in the
    /// target commit — so the correct commit to read depends on the side.
    ///
    /// Line numbers from the API are 1-based and inclusive.
    /// </summary>
    private async Task<string?> GetSnippetAsync(
        string project,
        RepositoryRef repo,
        PullRequestRef pr,
        CodeAnchor anchor,
        int contextLines,
        Dictionary<string, string[]?> cache,
        CancellationToken ct)
    {
        if (anchor.StartLine is null)
            return null;

        var commitId = anchor.IsLeftSide ? pr.TargetCommitId : pr.SourceCommitId;
        if (string.IsNullOrWhiteSpace(commitId))
            return null;

        var lines = await GetFileLinesAsync(project, repo, commitId, anchor.FilePath, cache, ct);
        if (lines is null || lines.Length == 0)
            return null;

        var start = anchor.StartLine.Value;
        var end = Math.Max(anchor.EndLine ?? start, start);

        // An "end" that points at column 1 of the following line is how the API encodes a
        // selection that stops at the end of the previous line. Pull it back so the snippet
        // does not show a stray extra line.
        if (anchor.EndOffset is 1 && end > start)
            end--;

        // Trim a runaway selection (someone highlighting a 900-line file) before padding.
        if (end - start + 1 > MaxSnippetLines)
            end = start + MaxSnippetLines - 1;

        var windowStart = Math.Max(1, start - Math.Max(0, contextLines));
        var windowEnd = Math.Min(lines.Length, end + Math.Max(0, contextLines));

        if (windowStart > lines.Length)
            return null;

        // Right-align the gutter so the numbers stay in a straight column.
        var gutterWidth = windowEnd.ToString().Length;
        var builder = new StringBuilder();

        for (var lineNumber = windowStart; lineNumber <= windowEnd; lineNumber++)
        {
            // ">" marks the lines the reviewer actually selected, as opposed to context.
            var marker = lineNumber >= start && lineNumber <= end ? ">" : " ";
            var text = lines[lineNumber - 1].TrimEnd();

            builder.Append(marker)
                   .Append(' ')
                   .Append(lineNumber.ToString().PadLeft(gutterWidth))
                   .Append(" | ")
                   .AppendLine(text);
        }

        return builder.ToString().TrimEnd();
    }

    /// <summary>
    /// Downloads a file at a specific commit and splits it into lines, caching the result.
    /// Returns null for anything unreadable: deleted files, binaries, or paths the PAT
    /// cannot see. A missing snippet is never fatal — the comment is still reported.
    /// </summary>
    private async Task<string[]?> GetFileLinesAsync(
        string project,
        RepositoryRef repo,
        string commitId,
        string filePath,
        Dictionary<string, string[]?> cache,
        CancellationToken ct)
    {
        var key = $"{repo.Id}|{commitId}|{filePath}";
        if (cache.TryGetValue(key, out var cached))
            return cached;

        var url = $"{Org}/{Enc(project)}/_apis/git/repositories/{Enc(repo.Id)}/items"
                + $"?path={Uri.EscapeDataString(filePath)}"
                + $"&versionDescriptor.versionType=commit"
                + $"&versionDescriptor.version={Uri.EscapeDataString(commitId)}"
                + $"&includeContent=true&$format=text&api-version={Api}";

        string[]? lines = null;

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Accept.Clear();
            request.Headers.Accept.ParseAdd("text/plain");

            using var response = await _http.SendAsync(request, ct);

            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                _log.LogDebug("File {Path} not present at commit {Commit}", filePath, commitId);
            }
            else if (!response.IsSuccessStatusCode)
            {
                _log.LogDebug("Item request failed ({Status}) for {Path}", (int)response.StatusCode, filePath);
            }
            else
            {
                var text = await response.Content.ReadAsStringAsync(ct);

                // Binary files come back as bytes; a NUL byte is a cheap, reliable signal.
                if (!text.Contains('\0'))
                    lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            }
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException && !ct.IsCancellationRequested)
        {
            _log.LogDebug(ex, "Could not download {Path} at {Commit}", filePath, commitId);
        }

        cache[key] = lines;
        return lines;
    }

    /// <summary>
    /// Pulls the code anchor off a thread. Prefers the right (new) side; falls back to the
    /// left (removed) side. Returns null for PR-level comments, which have no file context.
    /// </summary>
    private static CodeAnchor? ReadAnchor(JsonElement thread)
    {
        if (!thread.TryGetProperty("threadContext", out var context)
            || context.ValueKind != JsonValueKind.Object)
        {
            return null;
        }

        var filePath = ReadString(context, "filePath");
        if (string.IsNullOrWhiteSpace(filePath))
            return null;

        var (start, startOffset) = ReadPosition(context, "rightFileStart");
        var (end, endOffset) = ReadPosition(context, "rightFileEnd");
        var isLeftSide = false;

        if (start is null)
        {
            (start, startOffset) = ReadPosition(context, "leftFileStart");
            (end, endOffset) = ReadPosition(context, "leftFileEnd");
            isLeftSide = start is not null;
        }

        return new CodeAnchor(filePath, start, end, startOffset, endOffset, isLeftSide);

        static (int? Line, int? Offset) ReadPosition(JsonElement parent, string name)
        {
            if (!parent.TryGetProperty(name, out var position) || position.ValueKind != JsonValueKind.Object)
                return (null, null);

            return (ReadInt(position, "line"), ReadInt(position, "offset"));
        }
    }

    // -------------------------------------------------------------------------
    //  4.6 Markdown export
    // -------------------------------------------------------------------------

    public async Task<string> ExportMarkdownAsync(
        IReadOnlyList<ReviewComment> comments,
        PullRequestCommentFilter filter,
        string outputDirectory,
        string? fileName = null,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(comments);
        Directory.CreateDirectory(outputDirectory);

        fileName ??= $"PR-Comments-{DateTime.Now:yyyyMMdd-HHmm}.md";
        if (!fileName.EndsWith(".md", StringComparison.OrdinalIgnoreCase))
            fileName += ".md";

        var path = Path.Combine(outputDirectory, fileName);
        await File.WriteAllTextAsync(path, BuildMarkdown(comments, filter), Encoding.UTF8, ct);

        _log.LogInformation("Wrote {Count} comment(s) to {Path}", comments.Count, path);
        return path;
    }

    /// <summary>
    /// Builds the whole report: header, filter summary, per-reviewer totals, an index
    /// table, then one section per pull request with each comment and its code snippet.
    /// </summary>
    private string BuildMarkdown(IReadOnlyList<ReviewComment> comments, PullRequestCommentFilter filter)
    {
        var sb = new StringBuilder();

        var pullRequestCount = comments.Select(c => c.PullRequestId).Distinct().Count();

        sb.AppendLine("# Pull request review comments").AppendLine();
        sb.AppendLine($"**Organisation / project:** {_options.Organization} / {ProjectFor(filter)}  ");
        sb.AppendLine($"**Generated:** {DateTime.Now:dd MMM yyyy HH:mm}  ");
        sb.AppendLine($"**Totals:** {comments.Count} comment(s) across {pullRequestCount} pull request(s)").AppendLine();

        sb.AppendLine("## Filters applied").AppendLine();
        sb.AppendLine(filter.Describe()).AppendLine();

        if (comments.Count == 0)
        {
            sb.AppendLine("---").AppendLine();
            sb.AppendLine("No comments matched the filter.");
            return sb.ToString();
        }

        // --- per-reviewer totals ---
        sb.AppendLine("## Comments per reviewer").AppendLine();
        sb.AppendLine("| Reviewer | Comments | Pull requests |");
        sb.AppendLine("|---|---:|---:|");

        foreach (var group in comments
                     .GroupBy(c => c.ReviewerName, StringComparer.OrdinalIgnoreCase)
                     .OrderByDescending(g => g.Count()))
        {
            sb.AppendLine($"| {EscapeCell(group.Key)} | {group.Count()} | "
                        + $"{group.Select(c => c.PullRequestId).Distinct().Count()} |");
        }

        sb.AppendLine();

        // --- flat index, matching the requested output columns ---
        sb.AppendLine("## Index").AppendLine();
        sb.AppendLine("| PR ID | Reviewer | Comment date | PR created | Location | Link |");
        sb.AppendLine("|---|---|---|---|---|---|");

        foreach (var comment in comments)
        {
            sb.AppendLine(
                $"| {comment.PullRequestId} "
                + $"| {EscapeCell(comment.ReviewerName)} "
                + $"| {comment.CommentDate.LocalDateTime:dd MMM yyyy HH:mm} "
                + $"| {comment.PullRequestCreatedDate.LocalDateTime:dd MMM yyyy} "
                + $"| {EscapeCell(comment.LocationCaption)} "
                + $"| [open]({comment.CommentUrl}) |");
        }

        sb.AppendLine();

        // --- detail, grouped by pull request ---
        foreach (var prGroup in comments.GroupBy(c => new { c.PullRequestId, c.RepositoryName }))
        {
            var first = prGroup.First();

            sb.AppendLine("---").AppendLine();
            sb.AppendLine($"## PR {first.PullRequestId} — {first.PullRequestTitle}").AppendLine();
            sb.AppendLine("| | |");
            sb.AppendLine("|---|---|");
            sb.AppendLine($"| **PR ID** | {first.PullRequestId} |");
            sb.AppendLine($"| **Repository** | {EscapeCell(first.RepositoryName)} |");
            sb.AppendLine($"| **Raised by** | {EscapeCell(first.PullRequestAuthor)} |");
            sb.AppendLine($"| **Status** | {EscapeCell(first.PullRequestStatus)} |");
            sb.AppendLine($"| **PR created date** | {first.PullRequestCreatedDate.LocalDateTime:dd MMM yyyy HH:mm} |");
            sb.AppendLine($"| **PR link** | {first.PullRequestUrl} |");
            sb.AppendLine($"| **Comments** | {prGroup.Count()} |");
            sb.AppendLine();

            var index = 0;
            foreach (var comment in prGroup)
            {
                index++;
                var replyTag = comment.IsReply ? " _(reply)_" : string.Empty;

                sb.AppendLine($"### {index}. {comment.ReviewerName} — "
                            + $"{comment.CommentDate.LocalDateTime:dd MMM yyyy HH:mm}{replyTag}").AppendLine();

                sb.AppendLine($"- **Reviewer:** {comment.ReviewerName}"
                            + (string.IsNullOrWhiteSpace(comment.ReviewerEmail)
                                ? string.Empty
                                : $" ({comment.ReviewerEmail})"));
                sb.AppendLine($"- **Comment date:** {comment.CommentDate.LocalDateTime:dd MMM yyyy HH:mm}");
                sb.AppendLine($"- **Location:** {comment.LocationCaption}");

                if (!string.IsNullOrWhiteSpace(comment.ThreadStatus))
                    sb.AppendLine($"- **Thread status:** {comment.ThreadStatus}");

                sb.AppendLine($"- **Link:** {comment.CommentUrl}").AppendLine();

                if (!string.IsNullOrWhiteSpace(comment.CodeSnippet))
                {
                    sb.AppendLine("**Highlighted code**").AppendLine();

                    // The gutter ("> 42 | code") is plain text, so the fence stays unlabelled;
                    // a language label here would only mis-colour the line numbers.
                    var fence = FenceFor(comment.CodeSnippet);
                    sb.AppendLine(fence);
                    sb.AppendLine(comment.CodeSnippet);
                    sb.AppendLine(fence).AppendLine();
                }

                sb.AppendLine("**Comment**").AppendLine();
                sb.AppendLine(Quote(comment.Content)).AppendLine();
            }
        }

        return sb.ToString();
    }

    /// <summary>
    /// Reviewer comments are themselves Markdown and often contain fenced code. Picking a
    /// fence longer than the longest backtick run inside the snippet keeps the block from
    /// closing early and swallowing the rest of the document.
    /// </summary>
    private static string FenceFor(string content)
    {
        var longest = 0;
        var run = 0;

        foreach (var ch in content)
        {
            if (ch == '`')
            {
                run++;
                if (run > longest) longest = run;
            }
            else
            {
                run = 0;
            }
        }

        return new string('`', Math.Max(3, longest + 1));
    }

    /// <summary>Renders multi-line comment text as a Markdown block quote.</summary>
    private static string Quote(string content)
    {
        var lines = content.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        return string.Join("\n", lines.Select(l => l.Length == 0 ? ">" : "> " + l));
    }

    /// <summary>Pipes and newlines would break a Markdown table cell.</summary>
    private static string EscapeCell(string? value)
        => (value ?? string.Empty).Replace("|", "\\|").Replace("\n", " ").Replace("\r", " ");

    // -------------------------------------------------------------------------
    //  4.7 HTTP and JSON helpers
    // -------------------------------------------------------------------------

    private async Task<JsonDocument> GetJsonAsync(string url, CancellationToken ct)
    {
        using var response = await _http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);

        if (!response.IsSuccessStatusCode)
        {
            var body = await response.Content.ReadAsStringAsync(ct);
            if (body.Length > 600) body = body[..600];

            throw new HttpRequestException(
                $"Azure DevOps request failed ({(int)response.StatusCode} {response.ReasonPhrase}).\n"
                + $"URL: {url}\n{body}");
        }

        // A wrong or expired PAT is answered with a 200 HTML sign-in page rather than a 401,
        // which would otherwise surface as a confusing JSON parse error.
        var mediaType = response.Content.Headers.ContentType?.MediaType;
        if (mediaType is not null && mediaType.Contains("html", StringComparison.OrdinalIgnoreCase))
        {
            throw new HttpRequestException(
                "Azure DevOps returned an HTML sign-in page. The PAT is missing, expired, "
                + "or lacks the 'Code (Read)' scope for this organisation.");
        }

        return await JsonDocument.ParseAsync(
            await response.Content.ReadAsStreamAsync(ct), cancellationToken: ct);
    }

    private string BuildPullRequestUrl(string project, string repositoryName, int pullRequestId)
        => $"{_options.BaseUrl.TrimEnd('/')}/{_options.Organization}/{Enc(project)}"
         + $"/_git/{Enc(repositoryName)}/pullrequest/{pullRequestId}";

    /// <summary>Accepts "main" or "refs/heads/main" and always returns the full ref name.</summary>
    private static string ToRefName(string branch)
        => branch.StartsWith("refs/", StringComparison.OrdinalIgnoreCase)
            ? branch
            : "refs/heads/" + branch.TrimStart('/');

    /// <summary>
    /// A caller passing a bare date means "up to the end of that day". Midnight would
    /// otherwise exclude everything posted during the final day of the range.
    /// </summary>
    private static DateTimeOffset? NormaliseUpperBound(DateTimeOffset? value)
        => value is null
            ? null
            : value.Value.TimeOfDay == TimeSpan.Zero
                ? value.Value.AddDays(1).AddTicks(-1)
                : value;

    private static string ReadString(JsonElement element, string name)
        => element.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString() ?? string.Empty
            : string.Empty;

    private static string ReadNestedString(JsonElement element, string objectName, string propertyName)
        => element.TryGetProperty(objectName, out var nested) && nested.ValueKind == JsonValueKind.Object
            ? ReadString(nested, propertyName)
            : string.Empty;

    private static int? ReadInt(JsonElement element, string name)
        => element.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.Number
            ? value.GetInt32()
            : null;

    private static bool ReadBool(JsonElement element, string name)
        => element.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.True;

    private static DateTimeOffset? ReadDate(JsonElement element, string name)
        => element.TryGetProperty(name, out var value)
           && value.ValueKind == JsonValueKind.String
           && DateTimeOffset.TryParse(value.GetString(), out var parsed)
            ? parsed
            : null;

    private static Identity ReadIdentity(JsonElement element, string name)
    {
        if (!element.TryGetProperty(name, out var identity) || identity.ValueKind != JsonValueKind.Object)
            return new Identity("Unknown", string.Empty);

        return new Identity(
            ReadString(identity, "displayName") is { Length: > 0 } display ? display : "Unknown",
            ReadString(identity, "uniqueName"));
    }

    /// <summary>Maps a file extension to a Markdown fence language. Falls back to none.</summary>
    private static string? LanguageFor(string filePath)
    {
        var extension = Path.GetExtension(filePath).ToLowerInvariant();

        return extension switch
        {
            ".cs" => "csharp",
            ".ts" => "typescript",
            ".tsx" => "tsx",
            ".js" or ".jsx" => "javascript",
            ".html" or ".htm" => "html",
            ".css" or ".scss" or ".less" => "css",
            ".json" => "json",
            ".xml" or ".csproj" or ".config" or ".xaml" => "xml",
            ".yml" or ".yaml" => "yaml",
            ".sql" => "sql",
            ".ps1" => "powershell",
            ".sh" => "bash",
            ".razor" or ".cshtml" => "razor",
            ".py" => "python",
            ".java" => "java",
            ".md" => "markdown",
            _ => null
        };
    }

    // -------------------------------------------------------------------------
    //  4.8 Internal records
    // -------------------------------------------------------------------------

    private sealed record PullRequestRef(
        int Id,
        string Title,
        string Status,
        string Author,
        DateTimeOffset CreatedDate,
        string SourceCommitId,
        string TargetCommitId,
        string Url,
        RepositoryRef Repository);

    private sealed record Identity(string Name, string Email);

    /// <summary>Where a thread is pinned in the diff. Line numbers are 1-based, inclusive.</summary>
    private sealed record CodeAnchor(
        string FilePath,
        int? StartLine,
        int? EndLine,
        int? StartOffset,
        int? EndOffset,
        bool IsLeftSide);
}
