using SkyWorkItems.Models;

namespace SkyWorkItems.Services.DevOps;

/// <summary>
/// Read-only view over the Azure DevOps work tracking API that this app needs.
/// Kept narrow on purpose (ISP) so it can be faked in tests without a PAT.
///
/// Every call takes the project explicitly rather than reading it from configuration,
/// because the two modules in the app can be pointed at different projects at the same
/// time. The configured project is only the starting selection.
/// </summary>
public interface IAzureDevOpsClient
{
    /// <summary>Every team project in the organisation the PAT can see.</summary>
    Task<IReadOnlyList<ProjectRef>> GetProjectsAsync(CancellationToken ct = default);

    Task<IReadOnlyList<TeamRef>> GetTeamsAsync(string project, CancellationToken ct = default);

    Task<IReadOnlyList<IterationRef>> GetIterationsAsync(string project, string teamName, CancellationToken ct = default);

    Task<IReadOnlyList<int>> QueryWorkItemIdsAsync(string project, string teamName, string iterationPath, CancellationToken ct = default);

    Task<IReadOnlyList<WorkItemSummary>> GetSummariesAsync(string project, IReadOnlyList<int> ids, CancellationToken ct = default);

    Task<WorkItemDetail> GetDetailAsync(string project, int id, CancellationToken ct = default);

    /// <summary>Browser URL for a work item, used by the "open in browser" actions.</summary>
    string BuildWebUrl(string project, int workItemId);
}
