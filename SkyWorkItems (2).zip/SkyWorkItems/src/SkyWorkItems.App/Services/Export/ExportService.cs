using Microsoft.Extensions.Logging;
using SkyWorkItems.Services.DevOps;

namespace SkyWorkItems.Services.Export;

/// <summary>
/// Coordinates "fetch detail -> write file(s)". Knows nothing about Markdown or PDF
/// specifics; it just picks the exporters whose Format matches the request (DIP).
/// </summary>
public sealed class ExportService : IExportService
{
    private readonly IAzureDevOpsClient _devOps;
    private readonly IReadOnlyList<IWorkItemExporter> _exporters;
    private readonly ILogger<ExportService> _log;

    public ExportService(
        IAzureDevOpsClient devOps,
        IEnumerable<IWorkItemExporter> exporters,
        ILogger<ExportService> log)
    {
        _devOps = devOps;
        _exporters = exporters.ToList();
        _log = log;
    }

    public async Task<ExportResult> ExportAsync(
        string project,
        IReadOnlyList<int> ids,
        string format,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken ct = default)
    {
        var selected = SelectExporters(format);
        if (selected.Count == 0)
            throw new InvalidOperationException($"No exporter registered for format '{format}'.");

        Directory.CreateDirectory(outputDirectory);

        var files = new List<string>();
        var failures = new List<string>();
        var index = 0;

        foreach (var id in ids)
        {
            ct.ThrowIfCancellationRequested();
            index++;

            try
            {
                progress?.Report($"Exporting {index}/{ids.Count} — work item {id}…");

                var detail = await _devOps.GetDetailAsync(project, id, ct);

                foreach (var exporter in selected)
                    files.Add(await exporter.ExportAsync(detail, outputDirectory, ct));
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "Export failed for work item {Id}", id);
                failures.Add($"{id}: {ex.Message}");
            }
        }

        return new ExportResult(files, failures) { OutputDirectory = outputDirectory };
    }

    private List<IWorkItemExporter> SelectExporters(string format)
        => string.Equals(format, "Both", StringComparison.OrdinalIgnoreCase)
            ? _exporters.ToList()
            : _exporters
                .Where(e => string.Equals(e.Format, format, StringComparison.OrdinalIgnoreCase))
                .ToList();
}
