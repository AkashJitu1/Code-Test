using System.Windows;
using SkyWorkItems.ViewModels;

namespace SkyWorkItems.Views;

public partial class MainWindow : Window
{
    public MainWindow(ShellViewModel viewModel)
    {
        InitializeComponent();
        DataContext = viewModel;

        // Both modules start from the project list, and each keeps its own selection.
        // Loaded rather than the constructor so the window paints before the first call.
        Loaded += async (_, _) =>
        {
            await viewModel.WorkItems.LoadProjectsCommand.ExecuteAsync(null);
            await viewModel.PullRequests.LoadProjectsCommand.ExecuteAsync(null);
        };
    }
}
