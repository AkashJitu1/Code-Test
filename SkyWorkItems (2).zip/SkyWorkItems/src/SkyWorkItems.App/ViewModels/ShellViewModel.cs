using Microsoft.Extensions.Options;
using SkyWorkItems.Configuration;

namespace SkyWorkItems.ViewModels;

/// <summary>
/// Top-level window ViewModel. It owns nothing of its own beyond the caption — it just
/// holds the two module ViewModels so each tab keeps its own state, commands and status
/// line instead of everything piling into one class.
/// </summary>
public sealed class ShellViewModel
{
    public ShellViewModel(
        MainViewModel workItems,
        PullRequestsViewModel pullRequests,
        IOptions<AppSettings> settings)
    {
        WorkItems = workItems;
        PullRequests = pullRequests;

        var devOps = settings.Value.AzureDevOps;
        Organization = devOps.Organization;
        Project = devOps.Project;
    }

    public MainViewModel WorkItems { get; }

    public PullRequestsViewModel PullRequests { get; }

    public string Organization { get; }

    public string Project { get; }

    /// <summary>
    /// Only the organisation is shown in the app bar. Each tab carries its own project
    /// picker, so a single shared caption would be wrong half the time.
    /// </summary>
    public string OrganizationCaption => Organization;
}
