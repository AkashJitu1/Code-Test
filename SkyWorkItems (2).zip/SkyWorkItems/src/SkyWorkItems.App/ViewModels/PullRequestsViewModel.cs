using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Data;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SkyWorkItems.Configuration;
using SkyWorkItems.Models;
using SkyWorkItems.Services.DevOps;
using SkyWorkItems.Services.Shell;

namespace SkyWorkItems.ViewModels;

/// <summary>
/// Drives the "PR comments" module: builds a <see cref="PullRequestCommentFilter"/> from
/// the form, runs <see cref="IPullRequestCommentService"/>, and exposes the results for
/// the grid, the detail pane and the Markdown exports.
///
/// The project selection here is independent of the work-item tab — both modules hold
/// their own <c>SelectedProject</c>, so you can review PRs in one project while
/// exporting stories from another.
/// </summary>
public sealed partial class PullRequestsViewModel : ObservableObject
{
    /// <summary>Sentinel row in the repository picker meaning "search every repository".</summary>
    private static readonly RepositoryRef AllRepositories = new(string.Empty, "All repositories");

    private readonly IPullRequestCommentService _service;
    private readonly IFolderPicker _folderPicker;
    private readonly IDocumentPrinter _printer;
    private readonly AppSettings _settings;
    private readonly ILogger<PullRequestsViewModel> _log;

    /// <summary>
    /// The filter that produced the current results. Kept so an export reports the
    /// criteria that were actually run, not whatever the form has been edited to since.
    /// </summary>
    private PullRequestCommentFilter _lastRunFilter = new();

    public PullRequestsViewModel(
        IPullRequestCommentService service,
        IFolderPicker folderPicker,
        IDocumentPrinter printer,
        IOptions<AppSettings> settings,
        ILogger<PullRequestsViewModel> log)
    {
        _service = service;
        _folderPicker = folderPicker;
        _printer = printer;
        _settings = settings.Value;
        _log = log;

        CommentsView = CollectionViewSource.GetDefaultView(Comments);
        CommentsView.Filter = MatchesSearch;

        OutputDirectory = _settings.Export.ResolveDirectory();
        Status = "Pick a project, set a date range, then search.";
    }

    // ----- collections -------------------------------------------------------

    public ObservableCollection<ProjectRef> Projects { get; } = [];

    public ObservableCollection<RepositoryRef> Repositories { get; } = [];

    public ObservableCollection<ReviewComment> Comments { get; } = [];

    public ICollectionView CommentsView { get; }

    public string[] StatusOptions { get; } = ["all", "active", "completed", "abandoned"];

    // ----- filter form -------------------------------------------------------

    [ObservableProperty] private ProjectRef? _selectedProject;
    [ObservableProperty] private RepositoryRef? _selectedRepository;

    [ObservableProperty] private DateTime? _fromDate = DateTime.Today.AddDays(-30);
    [ObservableProperty] private DateTime? _toDate = DateTime.Today;

    /// <summary>Comma-separated; partial names and email aliases both work.</summary>
    [ObservableProperty] private string _reviewerNames = string.Empty;

    [ObservableProperty] private string _pullRequestStatus = "all";
    [ObservableProperty] private string _targetBranch = string.Empty;
    [ObservableProperty] private bool _includeReplies = true;
    [ObservableProperty] private bool _includeSystemComments;
    [ObservableProperty] private bool _includeCodeSnippets = true;
    [ObservableProperty] private int _codeContextLines = 2;
    [ObservableProperty] private int _maxPullRequests = 300;

    // ----- results -----------------------------------------------------------

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(SelectedPullRequestCaption))]
    private ReviewComment? _selectedComment;

    [ObservableProperty] private string _searchText = string.Empty;
    [ObservableProperty] private string _outputDirectory = string.Empty;
    [ObservableProperty] private string _status = string.Empty;

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(IsIdle))]
    private bool _isBusy;

    public bool IsIdle => !IsBusy;

    /// <summary>Project this module searches. Independent of the work-item tab.</summary>
    public string CurrentProject =>
        SelectedProject?.Name is { Length: > 0 } name ? name : _settings.AzureDevOps.Project;

    public string SelectedPullRequestCaption =>
        SelectedComment is null ? "Export this PR" : $"Export PR {SelectedComment.PullRequestId}";

    public string ResultCaption
    {
        get
        {
            if (Comments.Count == 0)
                return "No comments loaded";

            var visible = CommentsView.Cast<object>().Count();
            var pullRequests = Comments.Select(c => c.PullRequestId).Distinct().Count();

            return visible == Comments.Count
                ? $"{Comments.Count} comment(s) across {pullRequests} PR(s)"
                : $"{visible} of {Comments.Count} shown";
        }
    }

    // ----- project / repository ---------------------------------------------

    /// <summary>
    /// Repositories belong to a project, so a project change invalidates both the
    /// repository list and any results already on screen.
    /// </summary>
    partial void OnSelectedProjectChanged(ProjectRef? value)
    {
        Repositories.Clear();
        Comments.Clear();
        SelectedComment = null;
        SelectedRepository = null;

        OnPropertyChanged(nameof(CurrentProject));
        OnPropertyChanged(nameof(ResultCaption));

        if (value is not null)
            _ = LoadRepositoriesAsync();
    }

    [RelayCommand]
    private async Task LoadProjectsAsync()
    {
        await RunAsync("Loading projects…", async ct =>
        {
            var projects = await _service.GetProjectsAsync(ct);

            Projects.Clear();
            foreach (var project in projects)
                Projects.Add(project);

            SelectedProject = Projects.FirstOrDefault(p => string.Equals(
                                  p.Name, _settings.AzureDevOps.Project, StringComparison.OrdinalIgnoreCase))
                              ?? Projects.FirstOrDefault();

            Status = $"Loaded {Projects.Count} project(s).";
        });

        // OnSelectedProjectChanged fires while this command still holds the busy flag,
        // and RunAsync is single-flight — so the repository load has to be kicked off
        // again here, after IsBusy clears.
        if (SelectedProject is not null && Repositories.Count == 0)
            await LoadRepositoriesAsync();
    }

    [RelayCommand]
    private async Task LoadRepositoriesAsync()
    {
        if (SelectedProject is null)
            return;

        await RunAsync("Loading repositories…", async ct =>
        {
            var repositories = await _service.GetRepositoriesAsync(CurrentProject, ct);

            Repositories.Clear();
            Repositories.Add(AllRepositories);
            foreach (var repository in repositories)
                Repositories.Add(repository);

            SelectedRepository = AllRepositories;
            Status = $"{CurrentProject}: {repositories.Count} repository(ies).";
        });
    }

    // ----- search ------------------------------------------------------------

    partial void OnSearchTextChanged(string value)
    {
        CommentsView.Refresh();
        OnPropertyChanged(nameof(ResultCaption));
    }

    /// <summary>
    /// One box, every column. Terms are ANDed, so "660 ravi .cs" narrows by PR, reviewer
    /// and file in a single expression.
    /// </summary>
    private bool MatchesSearch(object item)
    {
        if (string.IsNullOrWhiteSpace(SearchText))
            return true;

        if (item is not ReviewComment comment)
            return false;

        var haystack = string.Join(' ',
            comment.PullRequestId,
            comment.PullRequestTitle,
            comment.RepositoryName,
            comment.ReviewerName,
            comment.ReviewerEmail,
            comment.FilePath,
            comment.Content);

        var terms = SearchText.Split(' ', StringSplitOptions.RemoveEmptyEntries
                                        | StringSplitOptions.TrimEntries);

        return terms.All(term => haystack.Contains(term, StringComparison.OrdinalIgnoreCase));
    }

    [RelayCommand]
    private void ClearSearch() => SearchText = string.Empty;

    // ----- commands ----------------------------------------------------------

    [RelayCommand]
    private async Task SearchAsync()
    {
        if (string.IsNullOrWhiteSpace(CurrentProject))
        {
            Status = "Pick a project first.";
            return;
        }

        await RunAsync("Searching pull request comments…", async ct =>
        {
            var filter = BuildFilter();
            _lastRunFilter = filter;

            Comments.Clear();
            SelectedComment = null;

            var progress = new Progress<string>(message => Status = message);
            var results = await _service.GetCommentsAsync(filter, progress, ct);

            foreach (var comment in results)
                Comments.Add(comment);

            OnPropertyChanged(nameof(ResultCaption));

            Status = results.Count == 0
                ? "No comments matched the filter."
                : $"Found {results.Count} comment(s) across "
                  + $"{results.Select(c => c.PullRequestId).Distinct().Count()} pull request(s).";
        });
    }

    /// <summary>Every comment from the last search, in one Markdown file.</summary>
    [RelayCommand]
    private Task ExportAllAsync()
    {
        if (Comments.Count == 0)
        {
            Status = "Run a search first.";
            return Task.CompletedTask;
        }

        var stamp = DateTime.Now.ToString("yyyyMMdd-HHmm");
        return WriteMarkdownAsync(
            Comments.ToList(),
            $"PR-Comments-{Slug(CurrentProject)}-{stamp}.md");
    }

    /// <summary>
    /// Only the pull request the selected row belongs to — still one file, just scoped.
    /// Useful when you want to hand a single PR's review trail to someone.
    /// </summary>
    [RelayCommand]
    private Task ExportSelectedPullRequestAsync()
    {
        if (SelectedComment is null)
        {
            Status = "Select a row first — the export covers that row's pull request.";
            return Task.CompletedTask;
        }

        var pullRequestId = SelectedComment.PullRequestId;
        var scoped = Comments.Where(c => c.PullRequestId == pullRequestId).ToList();

        var stamp = DateTime.Now.ToString("yyyyMMdd-HHmm");
        return WriteMarkdownAsync(scoped, $"PR-{pullRequestId}-Comments-{stamp}.md");
    }

    /// <summary>Only what the search box has left visible in the grid, in one file.</summary>
    [RelayCommand]
    private Task ExportVisibleAsync()
    {
        var visible = CommentsView.Cast<ReviewComment>().ToList();
        if (visible.Count == 0)
        {
            Status = "Nothing visible to export.";
            return Task.CompletedTask;
        }

        var stamp = DateTime.Now.ToString("yyyyMMdd-HHmm");
        return WriteMarkdownAsync(visible, $"PR-Comments-Filtered-{stamp}.md");
    }

    private Task WriteMarkdownAsync(IReadOnlyList<ReviewComment> comments, string fileName)
        => RunAsync("Writing Markdown…", async ct =>
        {
            var path = await _service.ExportMarkdownAsync(
                comments, _lastRunFilter, OutputDirectory, fileName, ct);

            Status = $"Wrote {comments.Count} comment(s) from "
                   + $"{comments.Select(c => c.PullRequestId).Distinct().Count()} PR(s) to {path}";
        });

    [RelayCommand]
    private void ClearFilters()
    {
        FromDate = DateTime.Today.AddDays(-30);
        ToDate = DateTime.Today;
        ReviewerNames = string.Empty;
        SelectedRepository = Repositories.FirstOrDefault();
        TargetBranch = string.Empty;
        PullRequestStatus = "all";
        IncludeReplies = true;
        IncludeSystemComments = false;
        IncludeCodeSnippets = true;
        CodeContextLines = 2;
        SearchText = string.Empty;
        Status = "Filters reset.";
    }

    [RelayCommand]
    private void BrowseOutputFolder()
    {
        var picked = _folderPicker.Pick("Choose where the Markdown report goes", OutputDirectory);
        if (!string.IsNullOrWhiteSpace(picked))
            OutputDirectory = picked;
    }

    [RelayCommand]
    private void OpenOutputFolder()
    {
        Directory.CreateDirectory(OutputDirectory);
        Process.Start(new ProcessStartInfo(OutputDirectory) { UseShellExecute = true });
    }

    /// <summary>
    /// Opens the comment's thread in the browser. Takes the row as a parameter so the
    /// grid link works without first changing the selection; falls back to the selection
    /// when invoked from the detail pane.
    /// </summary>
    [RelayCommand]
    private void OpenInBrowser(ReviewComment? comment)
    {
        var target = comment ?? SelectedComment;
        if (target is null)
            return;

        Process.Start(new ProcessStartInfo(target.CommentUrl) { UseShellExecute = true });
    }

    [RelayCommand]
    private void CopyComment()
    {
        if (SelectedComment is null)
            return;

        _printer.CopyToClipboard(FormatForClipboard(SelectedComment));
        Status = "Comment copied to the clipboard.";
    }

    [RelayCommand]
    private void CopySnippet()
    {
        if (string.IsNullOrWhiteSpace(SelectedComment?.CodeSnippet))
            return;

        _printer.CopyToClipboard(SelectedComment.CodeSnippet!);
        Status = "Code snippet copied to the clipboard.";
    }

    /// <summary>Prints the rows currently visible in the grid, one section per comment.</summary>
    [RelayCommand]
    private void PrintComments()
    {
        var visible = CommentsView.Cast<ReviewComment>().ToList();
        if (visible.Count == 0)
        {
            Status = "Nothing to print yet.";
            return;
        }

        var sections = new List<PrintSection>();

        foreach (var comment in visible)
        {
            sections.Add(new PrintSection(
                $"PR {comment.PullRequestId} — {comment.ReviewerName} — "
                + $"{comment.CommentDate.LocalDateTime:dd MMM yyyy HH:mm}",
                $"{comment.LocationCaption}\n{comment.Content}"));

            if (!string.IsNullOrWhiteSpace(comment.CodeSnippet))
                sections.Add(new PrintSection(string.Empty, comment.CodeSnippet!, Monospaced: true));
        }

        if (_printer.Print($"{CurrentProject} — pull request review comments", sections))
            Status = $"Sent {visible.Count} comment(s) to the printer.";
    }

    // ----- helpers -----------------------------------------------------------

    /// <summary>
    /// Maps the form onto the service filter.
    ///
    /// Note the date split: FromDate/ToDate bound the <i>comment</i> date, while the PR
    /// creation window is deliberately left open. A PR raised months ago can still pick
    /// up a review comment yesterday, and narrowing the PR list would hide exactly that.
    ///
    /// The repository picker carries a sentinel "All repositories" row with an empty id;
    /// that maps to an empty name list, which the service reads as "every repository".
    /// </summary>
    private PullRequestCommentFilter BuildFilter() => new()
    {
        Project = CurrentProject,
        FromDate = ToOffset(FromDate),
        ToDate = ToOffset(ToDate),
        ReviewerNames = SplitList(ReviewerNames),
        RepositoryNames = SelectedRepository is null || SelectedRepository.Id.Length == 0
            ? []
            : [SelectedRepository.Name],
        PullRequestStatus = string.IsNullOrWhiteSpace(PullRequestStatus) ? "all" : PullRequestStatus,
        TargetBranch = string.IsNullOrWhiteSpace(TargetBranch) ? null : TargetBranch.Trim(),
        IncludeReplies = IncludeReplies,
        IncludeSystemComments = IncludeSystemComments,
        IncludeCodeSnippets = IncludeCodeSnippets,
        CodeContextLines = Math.Clamp(CodeContextLines, 0, 10),
        MaxPullRequests = Math.Clamp(MaxPullRequests, 1, 2000)
    };

    /// <summary>Splits "Akash, priya.s@, Ravi" into trimmed, non-empty entries.</summary>
    private static IReadOnlyList<string> SplitList(string? value)
        => string.IsNullOrWhiteSpace(value)
            ? []
            : value.Split([',', ';'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

    /// <summary>
    /// The DatePicker hands back a local midnight DateTime. Converting through
    /// <see cref="DateTimeOffset"/> keeps the user's offset, which matters because the
    /// service compares against UTC timestamps from the API.
    /// </summary>
    private static DateTimeOffset? ToOffset(DateTime? value)
        => value is null ? null : new DateTimeOffset(DateTime.SpecifyKind(value.Value, DateTimeKind.Local));

    /// <summary>Project names can contain spaces and punctuation; file names cannot.</summary>
    private static string Slug(string value)
    {
        var clean = new string(value.Select(c => char.IsLetterOrDigit(c) ? c : '-').ToArray());
        return clean.Trim('-').Replace("--", "-");
    }

    private static string FormatForClipboard(ReviewComment comment)
    {
        var builder = new StringBuilder();
        builder.AppendLine($"PR {comment.PullRequestId} — {comment.PullRequestTitle}");
        builder.AppendLine($"Reviewer: {comment.ReviewerName}");
        builder.AppendLine($"Date: {comment.CommentDate.LocalDateTime:dd MMM yyyy HH:mm}");
        builder.AppendLine($"Location: {comment.LocationCaption}");
        builder.AppendLine($"Link: {comment.CommentUrl}");
        builder.AppendLine();

        if (!string.IsNullOrWhiteSpace(comment.CodeSnippet))
            builder.AppendLine(comment.CodeSnippet).AppendLine();

        builder.AppendLine(comment.Content);
        return builder.ToString();
    }

    /// <summary>Shared busy state, cancellation and error reporting for every command.</summary>
    private async Task RunAsync(string busyMessage, Func<CancellationToken, Task> work)
    {
        if (IsBusy)
            return;

        IsBusy = true;
        Status = busyMessage;

        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(15));
            await work(cts.Token);
        }
        catch (OperationCanceledException)
        {
            Status = "Cancelled — the search took too long.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Pull request comment operation failed: {Message}", busyMessage);
            Status = "Error: " + ex.Message.Replace('\n', ' ');
        }
        finally
        {
            IsBusy = false;
        }
    }
}
