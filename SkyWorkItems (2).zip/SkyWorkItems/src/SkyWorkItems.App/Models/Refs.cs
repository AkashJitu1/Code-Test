namespace SkyWorkItems.Models;

/// <summary>A team project in the organisation. Each module picks its own.</summary>
public sealed record ProjectRef(string Id, string Name)
{
    public override string ToString() => Name;
}

/// <summary>A Git repository inside a project.</summary>
public sealed record RepositoryRef(string Id, string Name)
{
    public override string ToString() => Name;
}

public sealed record TeamRef(string Id, string Name)
{
    public override string ToString() => Name;
}

public sealed record IterationRef(string Id, string Name, string Path, DateTime? StartDate, DateTime? FinishDate)
{
    public string Display => StartDate is null || FinishDate is null
        ? Name
        : $"{Name}  ({StartDate:dd MMM} - {FinishDate:dd MMM yyyy})";

    public override string ToString() => Display;
}

public sealed record DiscussionComment(string Author, DateTime CreatedDate, string Text);
