# Sky Work Items

WPF desktop app that pulls User Stories and Bugs from Azure DevOps for a chosen team
and sprint, exports each one as Markdown and/or PDF for Copilot, and lets you chat
about the selected item through Semantic Kernel.

Target: **.NET 10 (net10.0-windows)**, WPF, MVVM.

---

## 1. Configure

Everything lives in `src/SkyWorkItems.App/appsettings.json`, copied next to the exe on build.

```jsonc
{
  "AzureDevOps": {
    "BaseUrl": "https://dev.azure.com",
    "Organization": "softprocorp",
    "Project": "Sky",
    "PersonalAccessToken": "REPLACE_WITH_YOUR_PAT",
    "ApiVersion": "7.1",
    "WorkItemTypes": [ "User Story", "Bug" ],
    "Fields": {
      "AcceptanceCriteria": "Microsoft.VSTS.Common.AcceptanceCriteria",
      "RefinementNotes": "",
      "DevelopmentNotes": "",
      "TestingNotes": ""
    }
  },
  "Ai": { "...": "see section 4" },
  "Export": { "OutputDirectory": "", "Format": "Both" }
}
```

**PAT scope:** `Work Items (Read)` is enough. Create it at
`https://dev.azure.com/softprocorp/_usersSettings/tokens`.

**Keep secrets out of Git.** Three options, in order of preference:

1. Environment variables (prefix `SKY_`, `__` for nesting):
   ```powershell
   setx SKY_AzureDevOps__PersonalAccessToken "your-pat"
   setx SKY_Ai__ApiKey "your-key"
   ```
2. `appsettings.Local.json` next to the exe — loaded automatically, already gitignored.
3. Straight into `appsettings.json` (fine for a local spike, not for a shared repo).

### Custom fields

`Refinement Notes`, `Development Notes` and `Testing Notes` are custom fields, so their
reference names differ per organisation. Leave them blank in config and the app matches
them by normalised name (`Custom.Refinement_Notes`, `Sky.RefinementNotes`, etc. all hit).
If your process uses a name that doesn't contain those words, set the exact reference
name in `Fields`. You can list the real names with:

```
GET https://dev.azure.com/softprocorp/Sky/_apis/wit/fields?api-version=7.1
```

---

## 2. Build and run

```powershell
git clone <this folder>
cd SkyWorkItems
dotnet restore
dotnet build -c Release
dotnet run --project src\SkyWorkItems.App
```

Or open `SkyWorkItems.sln` in Visual Studio 2022+ and press F5.

Requires the .NET 10 SDK on **Windows** (WPF doesn't build or run on Linux/macOS).

### If restore complains about a package version

`Microsoft.SemanticKernel` is referenced as `1.*` so it always resolves to the current
1.x. `Microsoft.Extensions.*` is pinned to `10.0.0` and `PDFsharp.MigraDoc` to `6.2.0`.
If either pin doesn't exist in your feed yet, refresh it with:

```powershell
dotnet add src\SkyWorkItems.App package Microsoft.Extensions.Hosting
dotnet add src\SkyWorkItems.App package Microsoft.Extensions.Http
dotnet add src\SkyWorkItems.App package PDFsharp.MigraDoc
dotnet add src\SkyWorkItems.App package CommunityToolkit.Mvvm
```

---

## 3. Using it

1. App opens and loads teams for `softprocorp/Sky`.
2. Pick a **team** → sprints load; the current sprint is preselected.
3. **Load work items** → runs a WIQL query for User Stories and Bugs in that iteration.
4. Click a row → full details (Description, Acceptance Criteria, Refinement /
   Development / Testing Notes, Discussion) load on the right.
5. Each row has an **Open** link at the right end that opens that work item in the
   browser directly, without selecting the row first.
6. Tick rows, choose **Markdown / Pdf / Both**, pick an output folder, **Export selected**.
   Files land as `660033 - Title.pdf` / `.md` — upload those to Copilot.
6. **Chat with ProcesschatAgent** tab: ask questions grounded in the selected work item.

---

## 4. Semantic Kernel / Azure AI

```jsonc
"Ai": {
  "Enabled": true,
  "Endpoint": "https://processchat.services.ai.azure.com/",
  "ApiKey": "REPLACE_WITH_YOUR_KEY",
  "DeploymentName": "gpt-4o",
  "AgentName": "ProcesschatAgent",
  "SystemPrompt": "You are ProcesschatAgent, a requirements analyst. ..."
}
```

`SemanticKernelStoryChatService` builds a Kernel with
`AddAzureOpenAIChatCompletion(deployment, endpoint, apiKey)` and sends the exported
Markdown of the selected work item as the system prompt, so the agent answers from the
story and nothing else.

**One thing to check on your side.** Key-based auth works against an Azure OpenAI /
Azure AI Services endpoint plus a deployment name. If `ProcesschatAgent` is a
*persistent agent* in an AI Foundry project (one you created in the portal with its own
instructions and tools), that is a different API — `PersistentAgentsClient`, which wants
Entra ID rather than a raw key. The chat here is deliberately behind `IStoryChatService`
so swapping is one class:

```csharp
// Add: Azure.AI.Agents.Persistent, Azure.Identity,
//      Microsoft.SemanticKernel.Agents.AzureAI
var client = new PersistentAgentsClient(endpoint, new DefaultAzureCredential());
var definition = await client.Administration.GetAgentAsync(agentId);
var agent = new AzureAIAgent(definition, client);

AzureAIAgentThread thread = new(client);
await foreach (var response in agent.InvokeAsync(question, thread, ct))
    yield return response.Message.Content;
```

Register that implementation instead of `SemanticKernelStoryChatService` in `App.xaml.cs`
and nothing else changes. The Foundry agent packages are still preview and their API has
moved between releases, which is why the shipped default uses the stable chat-completion
path.

---

## 4a. Projects

Both tabs carry **their own project picker**, loaded from
`GET {org}/_apis/projects`. The project in `appsettings.json` is only the initial
selection. Changing it on either tab resets that tab's dependent lists — teams,
sprints and work items on one side, repositories and results on the other — because
all of them are project-scoped and stale values would silently query the wrong place.

Nothing in the service layer reads the project from configuration any more: every
`IAzureDevOpsClient` call takes it as a parameter, and `PullRequestCommentFilter` has
a `Project` property. That is what lets the two tabs sit on different projects at once.

## 4b. PR comments module

Second tab in the window. It drives `PullRequestCommentService` through
`PullRequestsViewModel`:

- **From / To** bound the *comment* date, not the PR date — a PR opened months ago
  still shows up if someone commented on it yesterday.
- **Reviewer(s)** is comma separated and matches partially against both display name
  and sign-in address, so `akash, priya.s@` works.
- **Repository** is a dropdown loaded from the selected project, with an
  "All repositories" entry at the top.
- Toggles for replies, system messages and code snippets, plus the number of context
  lines shown around each highlighted range.
- Three export buttons, all producing **one** Markdown file — only the scope differs:
  **Export all to one MD** (everything from the last search), **Export PR nnn** (just
  the selected row's pull request), and **Export filtered** (whatever the search box
  has left visible).
- Every grid row has an **Open** link at the right that opens that comment thread in
  the browser without changing the selection.
- The detail pane shows the highlighted code on a dark block; **Copy comment**,
  **Copy code** and **Print** are there for anything you want to paste elsewhere.

## 4c. UI

`Themes/Theme.xaml` is the design system — palette, type scale, and control templates
for buttons, inputs, combo boxes, check boxes, tabs, the data grid and scroll bars. It
is merged into `Application.Resources`, so implicit styles apply everywhere and views
only opt into keyed variants (`PrimaryButton`, `GhostButton`, `Card`, `Pill`,
`SelectableText`, `CodeText`).

Both grids have a single search box above them. It filters the default
`ICollectionView` rather than a second collection, so tick-box state survives filtering
and "select all" applies only to the rows currently visible.

Every read-only body of text — chat answers, work item fields, PR comments, code
snippets — is a chrome-less read-only `TextBox` rather than a `TextBlock`, because a
`TextBlock` cannot be selected with the mouse. Chat also has per-message **Copy**, plus
**Copy all** and **Print** (a `FlowDocument` through the standard print dialog).

---

## 5. Layout

```
src/SkyWorkItems.App/
  App.xaml(.cs)                  composition root — DI, config, PAT handler
  appsettings.json               all configuration
  Configuration/AppSettings.cs   strongly typed options
  Common/                        HTML→text, safe file names
  Models/                        TeamRef, IterationRef, WorkItemSummary/Detail, ChatTurn
  Services/DevOps/               IAzureDevOpsClient + REST 7.1 implementation, FieldResolver
  Services/Export/               IWorkItemExporter → Markdown, PDF; ExportService
  Services/Ai/                   IStoryChatService → Semantic Kernel
  Services/Shell/                IFolderPicker
  Services/Shell/                IFolderPicker, IDocumentPrinter
  Themes/Theme.xaml              palette, type scale, control templates
  ViewModels/                    ShellViewModel, MainViewModel, PullRequestsViewModel
  Views/                         MainWindow (shell), WorkItemsView, PullRequestsView
```

Design notes:

- **SRP** — the DevOps client only fetches, exporters only write, `ExportService` only
  orchestrates, the ViewModel only handles UI state.
- **OCP** — a new output format is a new `IWorkItemExporter` plus one DI line.
- **LSP/ISP** — interfaces are small and fully implementable; nothing throws
  `NotSupportedException`.
- **DIP** — the ViewModel depends on interfaces, never on `HttpClient`, MigraDoc, or
  Semantic Kernel types.
- **KISS** — raw REST + `System.Text.Json` instead of the `Microsoft.TeamFoundationServer.Client`
  SDK, which still targets .NET Standard 2.0 and drags in legacy dependencies. Five calls
  are all this app needs.

PDF uses PDFsharp/MigraDoc (MIT). QuestPDF's community licence is revenue-capped and
wouldn't be safe to ship inside FNF.

---

## 6. Troubleshooting

| Symptom | Cause |
|---|---|
| "returned an HTML sign-in page" | PAT missing, expired, or wrong org. DevOps returns a login page as 200, so the client checks for it explicitly. |
| 0 work items for a sprint | The team's iteration isn't the same as `System.IterationPath`, or the types aren't literally `User Story` / `Bug` (Agile vs Scrum process uses `Product Backlog Item`). Adjust `WorkItemTypes`. |
| Notes sections say "Not provided" | Custom field names don't match the hints — set them explicitly in `Fields`. |
| Chat says "not configured" | `Ai:ApiKey` still holds the placeholder. |
| `TF401019` on comments | Comments API is unavailable for that item; the export continues without the discussion. |
