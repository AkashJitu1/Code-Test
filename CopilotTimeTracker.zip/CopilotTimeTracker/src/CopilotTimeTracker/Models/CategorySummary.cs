using System.Windows.Media;

namespace CopilotTimeTracker.Models;

/// <summary>Aggregated time for a single category, used by the chart and legend.</summary>
public class CategorySummary
{
    public string Name { get; set; } = "";
    public string Color { get; set; } = "#7A7D9C";
    public double TotalSeconds { get; set; }
    public int Count { get; set; }

    /// <summary>0..1 relative to the busiest category, drives the bar length.</summary>
    public double Fraction { get; set; }

    public Brush Brush => Brushes.Gray.TryReplace(Color);

    public string TimeDisplay
    {
        get
        {
            var ts = TimeSpan.FromSeconds(TotalSeconds);
            return ts.TotalHours >= 1
                ? $"{ts.TotalHours:0.0} h"
                : $"{ts.TotalMinutes:0.0} min";
        }
    }

    public string CountDisplay => Count == 1 ? "1 question" : $"{Count} questions";
}
