using System.Windows.Media;

namespace CopilotTimeTracker.Models;

/// <summary>One classified Copilot question with its computed AI engagement time.</summary>
public class ChatRequestRecord
{
    public DateTime Timestamp { get; set; }
    public string Question { get; set; } = "";
    public string Category { get; set; } = "Other";
    public string CategoryColor { get; set; } = "#7A7D9C";
    public double EngagementSeconds { get; set; }
    public string Workspace { get; set; } = "";
    public string SessionId { get; set; } = "";

    // ---- display helpers (bound directly by the DataGrid) ----
    public string TimeDisplay => Timestamp.ToString("yyyy-MM-dd HH:mm");
    public string EngagementDisplay => $"{EngagementSeconds / 60.0:0.0} min";
    public string QuestionShort => Question.Length > 160 ? Question[..160] + "…" : Question;
    public Brush CategoryBrush => Brushes.Gray.TryReplace(CategoryColor);
}

internal static class BrushHelper
{
    /// <summary>Safe hex-to-brush conversion; falls back to the source brush on any error.</summary>
    public static Brush TryReplace(this Brush fallback, string hex)
    {
        try
        {
            var b = (Brush?)new BrushConverter().ConvertFromString(hex);
            if (b != null) { b.Freeze(); return b; }
        }
        catch { /* ignore malformed hex */ }
        return fallback;
    }
}
