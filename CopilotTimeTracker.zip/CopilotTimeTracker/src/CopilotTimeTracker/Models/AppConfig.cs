namespace CopilotTimeTracker.Models;

/// <summary>
/// Strongly-typed representation of appConfig.json.
/// Paths may contain environment variables like %APPDATA% which are expanded at read time.
/// </summary>
public class AppConfig
{
    public string WorkspaceStoragePath { get; set; } = @"%APPDATA%\Code\User\workspaceStorage";

    public List<string> AdditionalPaths { get; set; } = new();

    /// <summary>Folder (inside each workspace hash folder) that holds the chat session json files.</summary>
    public string ChatSessionsFolderName { get; set; } = "chatSessions";

    /// <summary>Idle gaps longer than this between two questions are capped (dev walked away).</summary>
    public int MaxEngagementGapMinutes { get; set; } = 10;

    /// <summary>Assumed engagement (seconds) for the last question in a session or when timestamps are missing.</summary>
    public int LastRequestSeconds { get; set; } = 120;
}
