using System.IO;
using System.Text.Json;
using CopilotTimeTracker.Models;

namespace CopilotTimeTracker.Services;

/// <summary>A single parsed question before engagement time is computed.</summary>
public class RawRequest
{
    public int Index { get; set; }
    public string Question { get; set; } = "";
    public DateTime Timestamp { get; set; }
    public bool HasRealTimestamp { get; set; }
}

public class RawSession
{
    public string Workspace { get; set; } = "";
    public string SessionId { get; set; } = "";
    public List<RawRequest> Requests { get; } = new();
}

/// <summary>
/// Reads VS Code / Copilot Chat session json files and extracts the questions and timestamps.
/// The chat session schema is not officially documented and shifts between Copilot versions,
/// so parsing is deliberately defensive: multiple field names are tried and anything missing
/// falls back to the file's last-write time. If your files differ, tweak the field names in
/// ExtractQuestion / ExtractTimestamp below.
/// </summary>
public class CopilotSessionReader
{
    public IReadOnlyList<RawSession> ReadAll(AppConfig config)
    {
        var sessions = new List<RawSession>();
        var roots = ConfigService.ResolveRoots(config);

        foreach (var root in roots)
        {
            // Each direct child of workspaceStorage is a workspace-hash folder.
            IEnumerable<string> workspaceDirs;
            try { workspaceDirs = Directory.EnumerateDirectories(root); }
            catch { continue; }

            foreach (var wsDir in workspaceDirs)
            {
                var chatDir = Path.Combine(wsDir, config.ChatSessionsFolderName);
                var files = new List<string>();

                if (Directory.Exists(chatDir))
                    files.AddRange(SafeEnumerate(chatDir, "*.json"));

                // Fallback: some versions place chat json elsewhere under the workspace.
                if (files.Count == 0)
                    files.AddRange(SafeEnumerate(wsDir, "*.json")
                        .Where(f => f.Contains("chat", StringComparison.OrdinalIgnoreCase)));

                var wsName = Path.GetFileName(wsDir);
                foreach (var file in files)
                {
                    var session = ParseFile(file, wsName);
                    if (session is { Requests.Count: > 0 }) sessions.Add(session);
                }
            }
        }

        return sessions;
    }

    private static IEnumerable<string> SafeEnumerate(string dir, string pattern)
    {
        try { return Directory.EnumerateFiles(dir, pattern, SearchOption.TopDirectoryOnly); }
        catch { return Enumerable.Empty<string>(); }
    }

    private static RawSession? ParseFile(string path, string workspace)
    {
        JsonDocument doc;
        DateTime fileTime;
        try
        {
            fileTime = File.GetLastWriteTime(path);
            doc = JsonDocument.Parse(File.ReadAllText(path));
        }
        catch { return null; }

        using (doc)
        {
            var root = doc.RootElement;
            if (root.ValueKind != JsonValueKind.Object) return null;
            if (!root.TryGetProperty("requests", out var requests) ||
                requests.ValueKind != JsonValueKind.Array)
                return null;

            var session = new RawSession
            {
                Workspace = workspace,
                SessionId = Path.GetFileNameWithoutExtension(path)
            };

            int i = 0;
            foreach (var req in requests.EnumerateArray())
            {
                var question = ExtractQuestion(req);
                if (string.IsNullOrWhiteSpace(question)) { i++; continue; }

                var (ts, real) = ExtractTimestamp(req, fileTime);
                session.Requests.Add(new RawRequest
                {
                    Index = i++,
                    Question = question.Trim(),
                    Timestamp = ts,
                    HasRealTimestamp = real
                });
            }

            return session;
        }
    }

    private static string ExtractQuestion(JsonElement req)
    {
        // message can be a string, or an object with "text" / "parts".
        if (req.TryGetProperty("message", out var msg))
        {
            if (msg.ValueKind == JsonValueKind.String)
                return msg.GetString() ?? "";

            if (msg.ValueKind == JsonValueKind.Object)
            {
                if (msg.TryGetProperty("text", out var t) && t.ValueKind == JsonValueKind.String)
                    return t.GetString() ?? "";

                if (msg.TryGetProperty("parts", out var parts) && parts.ValueKind == JsonValueKind.Array)
                {
                    var chunks = new List<string>();
                    foreach (var p in parts.EnumerateArray())
                    {
                        if (p.ValueKind == JsonValueKind.String) chunks.Add(p.GetString() ?? "");
                        else if (p.ValueKind == JsonValueKind.Object &&
                                 p.TryGetProperty("text", out var pt) && pt.ValueKind == JsonValueKind.String)
                            chunks.Add(pt.GetString() ?? "");
                    }
                    return string.Join(" ", chunks);
                }
            }
        }

        // Alternate field names seen in some versions.
        foreach (var key in new[] { "request", "prompt", "query" })
            if (req.TryGetProperty(key, out var v) && v.ValueKind == JsonValueKind.String)
                return v.GetString() ?? "";

        return "";
    }

    private static (DateTime, bool) ExtractTimestamp(JsonElement req, DateTime fallback)
    {
        // Epoch milliseconds on the request itself (most common).
        foreach (var key in new[] { "timestamp", "requestTime", "time" })
        {
            if (req.TryGetProperty(key, out var v) &&
                v.ValueKind == JsonValueKind.Number &&
                v.TryGetInt64(out var ms) && ms > 0)
            {
                try
                {
                    // Heuristic: values > ~ year 2001 in seconds are actually milliseconds.
                    var dto = ms > 100_000_000_000
                        ? DateTimeOffset.FromUnixTimeMilliseconds(ms)
                        : DateTimeOffset.FromUnixTimeSeconds(ms);
                    return (dto.LocalDateTime, true);
                }
                catch { /* out of range -> fall back */ }
            }
        }

        return (fallback, false);
    }
}
