namespace CopilotTimeTracker.Services;

public record CategoryDef(string Name, string Color, string[] Keywords);

/// <summary>
/// Rule-based classifier. Categories are evaluated top-to-bottom, so the most
/// specific ones are listed first (e.g. Integration before generic Backend unit tests,
/// Frontend before Backend so Angular ".spec" wins over the generic "unit test").
/// Adjust keywords here to tune accuracy for your team's phrasing.
/// </summary>
public static class CategoryClassifier
{
    // Priority order used for matching.
    public static readonly CategoryDef[] Categories =
    {
        new("Vulnerability Discovery", "#FF5D6C",
            new[] { "vulnerab", "security", "owasp", "sql injection", "xss", "cve",
                    "penetration", "pen test", "sast", "exploit", "csrf", "sanitiz" }),

        new("Integration Testing", "#FFC64B",
            new[] { "integration test", "end to end", "e2e", "webapplicationfactory",
                    "testcontainers", "integration testing", "api test" }),

        new("Postman Script", "#FF8A4C",
            new[] { "postman", "newman", "pm.test", "postman collection" }),

        new("Frontend Unit Test", "#B47BFF",
            new[] { "spec.ts", "jasmine", "karma", "angular test", "component test",
                    "testbed", ".spec", "fixture.detectchanges" }),

        new("Backend Unit Test", "#4E9BFF",
            new[] { "unit test", "xunit", "nunit", "mstest", "moq", "fakeiteasy",
                    "test the controller", "test the service", "test method" }),

        new("Generate Test Case", "#37D9A0",
            new[] { "test case", "test cases", "test scenario", "scenarios", "edge case" }),

        new("Other", "#7A7D9C", Array.Empty<string>())
    };

    /// <summary>Fixed display order (matches how the user thinks about the categories).</summary>
    public static readonly string[] DisplayOrder =
    {
        "Backend Unit Test",
        "Generate Test Case",
        "Postman Script",
        "Frontend Unit Test",
        "Integration Testing",
        "Vulnerability Discovery",
        "Other"
    };

    public static CategoryDef Classify(string? question)
    {
        var q = (question ?? string.Empty).ToLowerInvariant();
        foreach (var c in Categories)
        {
            if (c.Keywords.Length == 0) continue;
            foreach (var k in c.Keywords)
                if (q.Contains(k)) return c;
        }
        return Categories[^1]; // "Other"
    }

    public static string ColorFor(string name)
    {
        foreach (var c in Categories)
            if (c.Name == name) return c.Color;
        return "#7A7D9C";
    }
}
