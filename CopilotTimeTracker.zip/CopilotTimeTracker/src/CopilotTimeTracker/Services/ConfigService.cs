using System.IO;
using System.Text.Json;
using CopilotTimeTracker.Models;

namespace CopilotTimeTracker.Services;

public class ConfigService
{
    private static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };

    public string ConfigPath { get; } =
        Path.Combine(AppContext.BaseDirectory, "appConfig.json");

    public AppConfig Load()
    {
        try
        {
            if (File.Exists(ConfigPath))
            {
                var json = File.ReadAllText(ConfigPath);
                var cfg = JsonSerializer.Deserialize<AppConfig>(json, Options);
                if (cfg != null) return cfg;
            }
        }
        catch { /* fall through to defaults */ }

        var fallback = new AppConfig();
        TrySave(fallback);
        return fallback;
    }

    public void TrySave(AppConfig config)
    {
        try { File.WriteAllText(ConfigPath, JsonSerializer.Serialize(config, Options)); }
        catch { /* non-fatal */ }
    }

    /// <summary>Expands %VAR% tokens and returns only paths that exist on disk.</summary>
    public static IReadOnlyList<string> ResolveRoots(AppConfig config)
    {
        var roots = new List<string>();
        void Add(string? raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return;
            var expanded = Environment.ExpandEnvironmentVariables(raw);
            if (Directory.Exists(expanded) && !roots.Contains(expanded))
                roots.Add(expanded);
        }

        Add(config.WorkspaceStoragePath);
        foreach (var p in config.AdditionalPaths) Add(p);
        return roots;
    }
}
