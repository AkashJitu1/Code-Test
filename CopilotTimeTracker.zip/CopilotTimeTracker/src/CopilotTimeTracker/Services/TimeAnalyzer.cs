using CopilotTimeTracker.Models;

namespace CopilotTimeTracker.Services;

/// <summary>
/// Turns raw sessions into classified per-question records with an "AI engagement time",
/// then aggregates them into per-category totals for a date range.
///
/// Engagement model (validated against real session data):
///   Within a session ordered by time, the time a developer spends working with a given
///   answer is approximated by the gap until the *next* question, capped at
///   MaxEngagementGapMinutes (so walking away for lunch doesn't inflate a category).
///   The last question in a session — and any session lacking real timestamps — uses the
///   fixed LastRequestSeconds estimate.
/// </summary>
public class TimeAnalyzer
{
    public List<ChatRequestRecord> BuildRecords(IReadOnlyList<RawSession> sessions, AppConfig config)
    {
        double capSeconds = Math.Max(1, config.MaxEngagementGapMinutes) * 60.0;
        double lastSeconds = Math.Max(1, config.LastRequestSeconds);

        var records = new List<ChatRequestRecord>();

        foreach (var session in sessions)
        {
            var ordered = session.Requests
                .OrderBy(r => r.Timestamp)
                .ThenBy(r => r.Index)
                .ToList();

            bool hasRealTimeline = ordered.Count(r => r.HasRealTimestamp) >= 2;

            for (int i = 0; i < ordered.Count; i++)
            {
                var cur = ordered[i];
                double engagement;

                if (hasRealTimeline && i < ordered.Count - 1)
                {
                    var gap = (ordered[i + 1].Timestamp - cur.Timestamp).TotalSeconds;
                    engagement = Math.Clamp(gap, 0, capSeconds);
                    if (engagement <= 0) engagement = lastSeconds; // out-of-order / same second
                }
                else
                {
                    engagement = lastSeconds;
                }

                var def = CategoryClassifier.Classify(cur.Question);
                records.Add(new ChatRequestRecord
                {
                    Timestamp = cur.Timestamp,
                    Question = cur.Question,
                    Category = def.Name,
                    CategoryColor = def.Color,
                    EngagementSeconds = engagement,
                    Workspace = session.Workspace,
                    SessionId = session.SessionId
                });
            }
        }

        return records;
    }

    /// <summary>Filters records to [from, to] (inclusive of the whole 'to' day).</summary>
    public static List<ChatRequestRecord> Filter(IEnumerable<ChatRequestRecord> records, DateTime from, DateTime to)
    {
        var lower = from.Date;
        var upperExclusive = to.Date.AddDays(1);
        return records
            .Where(r => r.Timestamp >= lower && r.Timestamp < upperExclusive)
            .OrderByDescending(r => r.Timestamp)
            .ToList();
    }

    /// <summary>Aggregates filtered records into every display category (zero-filled).</summary>
    public static List<CategorySummary> Summarize(IReadOnlyList<ChatRequestRecord> records)
    {
        var byCategory = records
            .GroupBy(r => r.Category)
            .ToDictionary(g => g.Key, g => (Seconds: g.Sum(x => x.EngagementSeconds), Count: g.Count()));

        var summaries = new List<CategorySummary>();
        foreach (var name in CategoryClassifier.DisplayOrder)
        {
            byCategory.TryGetValue(name, out var agg);
            summaries.Add(new CategorySummary
            {
                Name = name,
                Color = CategoryClassifier.ColorFor(name),
                TotalSeconds = agg.Seconds,
                Count = agg.Count
            });
        }

        var max = summaries.Count == 0 ? 0 : summaries.Max(s => s.TotalSeconds);
        foreach (var s in summaries)
            s.Fraction = max > 0 ? s.TotalSeconds / max : 0;

        return summaries;
    }
}
