using System.Windows;

namespace CopilotTimeTracker;

public partial class App : Application
{
}
