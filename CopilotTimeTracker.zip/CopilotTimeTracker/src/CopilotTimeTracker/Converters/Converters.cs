using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace CopilotTimeTracker.Converters;

/// <summary>
/// Converts a 0..1 fraction into a star GridLength so a two-column grid renders a
/// proportional bar. Pass ConverterParameter="inverse" for the remaining (empty) column.
/// </summary>
public class FractionToGridLengthConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        double f = value is double d ? d : 0;
        f = Math.Clamp(f, 0, 1);

        bool inverse = string.Equals(parameter as string, "inverse", StringComparison.OrdinalIgnoreCase);
        double v = inverse ? 1 - f : f;
        if (v <= 0) v = 0.0001; // avoid a zero-star column collapsing oddly
        return new GridLength(v, GridUnitType.Star);
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

/// <summary>True when a count/number is zero — used to show an "empty state" message.</summary>
public class ZeroToVisibleConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        int n = value switch
        {
            int i => i,
            double dd => (int)dd,
            _ => 1
        };
        return n == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

/// <summary>Inverse of the above: collapse when zero, show when there is data.</summary>
public class NonZeroToVisibleConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        int n = value switch
        {
            int i => i,
            double dd => (int)dd,
            _ => 0
        };
        return n != 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
