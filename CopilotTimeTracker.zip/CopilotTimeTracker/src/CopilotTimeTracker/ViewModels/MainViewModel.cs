using System.Collections.ObjectModel;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CopilotTimeTracker.Models;
using CopilotTimeTracker.Services;

namespace CopilotTimeTracker.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly ConfigService _configService = new();
    private readonly CopilotSessionReader _reader = new();
    private readonly TimeAnalyzer _analyzer = new();

    private List<ChatRequestRecord> _allRecords = new();

    [ObservableProperty] private DateTime fromDate = DateTime.Today.AddDays(-7);
    [ObservableProperty] private DateTime toDate = DateTime.Today;
    [ObservableProperty] private bool isLoading;
    [ObservableProperty] private string statusText = "Select a date range and click Analyze.";

    [ObservableProperty] private int totalSessions;
    [ObservableProperty] private int totalRequests;
    [ObservableProperty] private string totalTimeDisplay = "0 min";
    [ObservableProperty] private string topCategory = "—";

    public ObservableCollection<CategorySummary> Categories { get; } = new();
    public ObservableCollection<ChatRequestRecord> Details { get; } = new();

    public MainViewModel()
    {
        // Kick off an initial load so the window isn't empty on open.
        _ = LoadAsync();
    }

    [RelayCommand]
    private async Task LoadAsync()
    {
        if (IsLoading) return;
        IsLoading = true;
        StatusText = "Scanning workspaceStorage…";

        var from = FromDate;
        var to = ToDate;

        try
        {
            var (records, sessionCount) = await Task.Run(() =>
            {
                var config = _configService.Load();
                var sessions = _reader.ReadAll(config);
                var recs = _analyzer.BuildRecords(sessions, config);
                return (recs, sessions.Count);
            });

            _allRecords = records;

            var filtered = TimeAnalyzer.Filter(_allRecords, from, to);
            var summaries = TimeAnalyzer.Summarize(filtered);

            Categories.Clear();
            foreach (var s in summaries) Categories.Add(s);

            Details.Clear();
            foreach (var r in filtered) Details.Add(r);

            TotalSessions = sessionCount;
            TotalRequests = filtered.Count;
            var totalSeconds = filtered.Sum(r => r.EngagementSeconds);
            TotalTimeDisplay = FormatDuration(totalSeconds);

            var top = summaries
                .Where(s => s.TotalSeconds > 0)
                .OrderByDescending(s => s.TotalSeconds)
                .FirstOrDefault();
            TopCategory = top?.Name ?? "—";

            StatusText = filtered.Count == 0
                ? "No Copilot questions found in this date range."
                : $"{filtered.Count} questions across {sessionCount} sessions · " +
                  $"{from:yyyy-MM-dd} → {to:yyyy-MM-dd}";
        }
        catch (Exception ex)
        {
            StatusText = "Error: " + ex.Message;
        }
        finally
        {
            IsLoading = false;
        }
    }

    private static string FormatDuration(double seconds)
    {
        var ts = TimeSpan.FromSeconds(seconds);
        if (ts.TotalHours >= 1) return $"{ts.TotalHours:0.0} h";
        return $"{ts.TotalMinutes:0.0} min";
    }
}
