Optional demo data.

To see the dashboard populated without real Copilot history, add this folder's
workspaceStorage path to "AdditionalPaths" in appConfig.json, e.g.:

  "AdditionalPaths": [ "C:\\path\\to\\sample-data\\workspaceStorage" ]

These demo questions have no timestamps, so the app dates them by file time
(around when you unzip), and each shows up under the default last-7-days range.
