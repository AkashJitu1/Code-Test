@echo off
echo Building Copilot AI Time Tracker...
dotnet build -c Release
if %ERRORLEVEL% NEQ 0 ( echo Build failed & exit /b 1 )
echo.
echo Launching...
dotnet run --project src\CopilotTimeTracker\CopilotTimeTracker.csproj -c Release
