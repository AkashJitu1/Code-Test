# Copilot AI Time Tracker (WPF · .NET 8 · MVVM)

A desktop dashboard that reads GitHub **Copilot Chat** session files written by VS Code,
classifies each question, and shows **how much time you spent with the AI** per activity
across a selected date range:

- Backend Unit Test
- Generate Test Case
- Postman Script
- Frontend Unit Test
- Integration Testing
- Vulnerability Discovery
- (Other)

No IDE extension required — it just parses the JSON that Copilot already writes to disk.

---

## Requirements

- Windows 10/11
- **.NET 8 SDK** (Desktop) — https://dotnet.microsoft.com/download/dotnet/8.0
- Or Visual Studio 2022/2026 with the *.NET desktop development* workload

## Build & run

**Option A — command line**
```bat
cd CopilotTimeTracker
dotnet build -c Release
dotnet run --project src\CopilotTimeTracker\CopilotTimeTracker.csproj -c Release
```

**Option B — Visual Studio**
Open `CopilotTimeTracker.sln`, press **F5**.

The first build restores a single NuGet package (`CommunityToolkit.Mvvm`).

---

## Configuration — `appConfig.json`

Lives next to the built exe (copied from `src\CopilotTimeTracker\appConfig.json`).

```json
{
  "WorkspaceStoragePath": "%APPDATA%\\Code\\User\\workspaceStorage",
  "AdditionalPaths": [
    "%APPDATA%\\Code - Insiders\\User\\workspaceStorage"
  ],
  "ChatSessionsFolderName": "chatSessions",
  "MaxEngagementGapMinutes": 10,
  "LastRequestSeconds": 120
}
```

- **WorkspaceStoragePath / AdditionalPaths** — folders scanned. Each direct sub-folder is a
  workspace hash; the app looks inside `<hash>\chatSessions\*.json`. Environment variables
  like `%APPDATA%` are expanded automatically. Add more paths (e.g. a copied team share) as needed.
- **MaxEngagementGapMinutes** — idle gaps longer than this between two questions are capped,
  so stepping away for lunch doesn't inflate a category.
- **LastRequestSeconds** — assumed time for the last question in a session (and for sessions
  that have no per-request timestamps).

---

## How "AI time" is measured

Each question is timed by the gap until the **next** question in the same session (capped by
`MaxEngagementGapMinutes`). The last question in a session uses `LastRequestSeconds`. Times are
summed per category. This approximates *time spent working with an answer* rather than raw
model latency (which the session files don't reliably store).

## How classification works

Rule-based keyword matching in `Services/CategoryClassifier.cs`, evaluated most-specific first
(e.g. Integration before generic Backend unit tests; Angular `.spec`/jasmine → Frontend before
Backend). **Edit the keyword lists there** to match your team's phrasing, or later swap in an
LLM call (Semantic Kernel) if you want smarter classification.

---

## Adapting to a different chat JSON schema

Copilot's session schema isn't officially documented and shifts between versions. Parsing is
defensive (`Services/CopilotSessionReader.cs`): it tries `message.text`, `message.parts`,
`message` as string, then `request`/`prompt`/`query`, and reads `timestamp`/`requestTime`/`time`
(epoch ms), falling back to the file's last-write time.

If your files look different: open one from `%APPDATA%\Code\User\workspaceStorage\<hash>\chatSessions\`
and adjust `ExtractQuestion` / `ExtractTimestamp` accordingly.

## Visual Studio 2026 support

VS stores Copilot logs under `%LOCALAPPDATA%\Microsoft\VisualStudio\<version>\`. That format is
messier and not wired up here yet — add a second reader modeled on `CopilotSessionReader` and feed
its `RawSession` list into `TimeAnalyzer`.

---

## Project layout

```
src/CopilotTimeTracker/
  Models/            AppConfig, ChatRequestRecord, CategorySummary
  Services/          ConfigService, CopilotSessionReader, CategoryClassifier, TimeAnalyzer
  ViewModels/        MainViewModel  (CommunityToolkit.Mvvm)
  Views/             MainWindow.xaml
  Converters/        bar-chart + visibility converters
  Themes/            Styles.xaml   (dark theme)
  appConfig.json
```
