using System.IO;

namespace SkyWorkItems.Configuration;

/// <summary>Root of appsettings.json. Bound once at startup.</summary>
public sealed class AppSettings
{
    public AzureDevOpsOptions AzureDevOps { get; set; } = new();
    public AiOptions Ai { get; set; } = new();
    public ExportOptions Export { get; set; } = new();
}

public sealed class AzureDevOpsOptions
{
    public string BaseUrl { get; set; } = "https://dev.azure.com";
    public string Organization { get; set; } = string.Empty;
    public string Project { get; set; } = string.Empty;
    public string PersonalAccessToken { get; set; } = string.Empty;
    public string ApiVersion { get; set; } = "7.1";
    public string[] WorkItemTypes { get; set; } = ["User Story", "Bug"];
    public FieldMapOptions Fields { get; set; } = new();
}

/// <summary>
/// Reference names of the rich-text fields. Leave a value blank and the client
/// discovers the field by matching its reference name (see FieldResolver).
/// </summary>
public sealed class FieldMapOptions
{
    public string AcceptanceCriteria { get; set; } = "Microsoft.VSTS.Common.AcceptanceCriteria";
    public string RefinementNotes { get; set; } = string.Empty;
    public string DevelopmentNotes { get; set; } = string.Empty;
    public string TestingNotes { get; set; } = string.Empty;
}

public sealed class AiOptions
{
    public bool Enabled { get; set; } = true;
    public string Endpoint { get; set; } = string.Empty;
    public string ApiKey { get; set; } = string.Empty;
    public string DeploymentName { get; set; } = "gpt-4o";
    public string AgentName { get; set; } = "ProcesschatAgent";
    public string SystemPrompt { get; set; } = string.Empty;
}

public sealed class ExportOptions
{
    /// <summary>Blank means &lt;MyDocuments&gt;\SkyWorkItems.</summary>
    public string OutputDirectory { get; set; } = string.Empty;

    /// <summary>Markdown | Pdf | Both</summary>
    public string Format { get; set; } = "Both";

    public string ResolveDirectory()
    {
        if (!string.IsNullOrWhiteSpace(OutputDirectory))
            return OutputDirectory;

        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "SkyWorkItems");
    }
}
