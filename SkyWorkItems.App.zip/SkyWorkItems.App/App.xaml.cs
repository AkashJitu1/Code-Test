using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Windows;
using System.Windows.Threading;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using SkyWorkItems.Configuration;
using SkyWorkItems.Services.Ai;
using SkyWorkItems.Services.DevOps;
using SkyWorkItems.Services.Export;
using SkyWorkItems.Services.Shell;
using SkyWorkItems.ViewModels;
using SkyWorkItems.Views;

namespace SkyWorkItems;

public partial class App : Application
{
    private readonly IHost _host;

    public App()
    {
        var builder = Host.CreateApplicationBuilder();

        builder.Configuration
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddJsonFile("appsettings.Local.json", optional: true, reloadOnChange: true)
            .AddEnvironmentVariables("SKY_");

        builder.Services.Configure<AppSettings>(builder.Configuration);

        // --- Azure DevOps (PAT over Basic auth) ---------------------------------
        builder.Services.AddHttpClient<IAzureDevOpsClient, AzureDevOpsClient>((sp, http) =>
        {
            var options = sp.GetRequiredService<IOptions<AppSettings>>().Value.AzureDevOps;

            http.BaseAddress = new Uri(options.BaseUrl.TrimEnd('/') + "/");
            http.Timeout = TimeSpan.FromSeconds(120);
            http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Azure DevOps expects Basic auth with an empty user name and the PAT as password.
            var credentials = Convert.ToBase64String(
                Encoding.ASCII.GetBytes(":" + options.PersonalAccessToken));
            http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);
        });

        // --- Export -------------------------------------------------------------
        builder.Services.AddSingleton<IWorkItemExporter, MarkdownWorkItemExporter>();
        builder.Services.AddSingleton<IWorkItemExporter, PdfWorkItemExporter>();
        builder.Services.AddSingleton<IExportService, ExportService>();

        // --- AI / shell ---------------------------------------------------------
        builder.Services.AddSingleton<IStoryChatService, SemanticKernelStoryChatService>();
        builder.Services.AddSingleton<IFolderPicker, WpfFolderPicker>();

        // --- UI -----------------------------------------------------------------
        builder.Services.AddSingleton<MainViewModel>();
        builder.Services.AddSingleton<MainWindow>();

        _host = builder.Build();
    }

    protected override async void OnStartup(StartupEventArgs e)
    {
        DispatcherUnhandledException += OnDispatcherUnhandledException;

        try
        {
            await _host.StartAsync();
            _host.Services.GetRequiredService<MainWindow>().Show();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "The app could not start.\n\n" + ex.Message
                + "\n\nCheck that appsettings.json sits next to the executable and is valid JSON.",
                "Sky Work Items", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
            return;
        }

        base.OnStartup(e);
    }

    protected override async void OnExit(ExitEventArgs e)
    {
        using (_host)
        {
            await _host.StopAsync(TimeSpan.FromSeconds(5));
        }

        base.OnExit(e);
    }

    private static void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        MessageBox.Show(e.Exception.Message, "Unexpected error",
            MessageBoxButton.OK, MessageBoxImage.Warning);
        e.Handled = true;
    }
}
