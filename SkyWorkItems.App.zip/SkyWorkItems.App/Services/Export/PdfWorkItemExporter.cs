using MigraDoc.DocumentObjectModel;
using MigraDoc.DocumentObjectModel.Tables;
using MigraDoc.Rendering;
using PdfSharp.Fonts;
using SkyWorkItems.Common;
using SkyWorkItems.Models;
using System.IO;

namespace SkyWorkItems.Services.Export;

/// <summary>
/// PDF via PDFsharp/MigraDoc (MIT licence — safe for commercial use, unlike the
/// QuestPDF community licence, which is revenue-capped).
/// </summary>
public sealed class PdfWorkItemExporter : IWorkItemExporter
{
    private const string BodyFont = "Segoe UI";

    static PdfWorkItemExporter()
    {
        // PDFsharp 6 needs to be told it may use the installed Windows fonts.
        GlobalFontSettings.UseWindowsFontsUnderWindows = true;
    }

    public string Format => "Pdf";

    public Task<string> ExportAsync(WorkItemDetail item, string outputDirectory, CancellationToken ct = default)
    {
        Directory.CreateDirectory(outputDirectory);
        var path = Path.Combine(outputDirectory, FileNames.Safe(item.Id, item.Title) + ".pdf");

        var document = BuildDocument(item);

        var renderer = new PdfDocumentRenderer { Document = document };
        renderer.RenderDocument();
        renderer.PdfDocument.Info.Title = $"{item.WorkItemType} {item.Id} - {item.Title}";
        renderer.PdfDocument.Info.Subject = item.IterationPath;
        renderer.PdfDocument.Save(path);

        return Task.FromResult(path);
    }

    private static Document BuildDocument(WorkItemDetail item)
    {
        var document = new Document();
        document.Info.Title = item.Title;

        var normal = document.Styles["Normal"]!;
        normal.Font.Name = BodyFont;
        normal.Font.Size = 10.5;
        normal.ParagraphFormat.SpaceAfter = Unit.FromPoint(6);

        var heading1 = document.Styles["Heading1"]!;
        heading1.Font.Name = BodyFont;
        heading1.Font.Size = 16;
        heading1.Font.Bold = true;
        heading1.ParagraphFormat.SpaceBefore = Unit.FromPoint(6);
        heading1.ParagraphFormat.SpaceAfter = Unit.FromPoint(10);

        var heading2 = document.Styles["Heading2"]!;
        heading2.Font.Name = BodyFont;
        heading2.Font.Size = 12.5;
        heading2.Font.Bold = true;
        heading2.Font.Color = Color.FromRgb(31, 78, 121);
        heading2.ParagraphFormat.SpaceBefore = Unit.FromPoint(12);
        heading2.ParagraphFormat.SpaceAfter = Unit.FromPoint(4);

        var section = document.AddSection();
        section.PageSetup.PageFormat = PageFormat.A4;
        section.PageSetup.TopMargin = Unit.FromCentimeter(2);
        section.PageSetup.BottomMargin = Unit.FromCentimeter(2);
        section.PageSetup.LeftMargin = Unit.FromCentimeter(2);
        section.PageSetup.RightMargin = Unit.FromCentimeter(2);

        var footer = section.Footers.Primary.AddParagraph();
        footer.AddText($"{item.WorkItemType} {item.Id}  •  page ");
        footer.AddPageField();
        footer.Format.Font.Size = 8;
        footer.Format.Font.Color = Color.FromRgb(120, 120, 120);
        footer.Format.Alignment = ParagraphAlignment.Center;

        section.AddParagraph($"[{item.WorkItemType} {item.Id}] {item.Title}", "Heading1");

        AddMetadata(section, item);

        AddSection(section, "Description", item.Description);
        AddSection(section, "Acceptance Criteria", item.AcceptanceCriteria);
        AddSection(section, "Refinement Notes", item.RefinementNotes);
        AddSection(section, "Development Notes", item.DevelopmentNotes);
        AddSection(section, "Testing Notes", item.TestingNotes);

        section.AddParagraph("Discussion", "Heading2");
        if (item.Discussion.Count == 0)
        {
            AddBody(section, "No comments.", italic: true);
        }
        else
        {
            foreach (var comment in item.Discussion)
            {
                var header = section.AddParagraph($"{comment.Author} — {comment.CreatedDate:dd MMM yyyy HH:mm}");
                header.Format.Font.Bold = true;
                header.Format.Font.Size = 10;
                header.Format.SpaceBefore = Unit.FromPoint(8);
                header.Format.SpaceAfter = Unit.FromPoint(2);

                AddBody(section, comment.Text);
            }
        }

        return document;
    }

    private static void AddMetadata(Section section, WorkItemDetail item)
    {
        var table = section.AddTable();
        table.Borders.Width = 0.5;
        table.Borders.Color = Color.FromRgb(210, 210, 210);
        table.AddColumn(Unit.FromCentimeter(4));
        table.AddColumn(Unit.FromCentimeter(12.5));

        AddRow(table, "State", Or(item.State));
        AddRow(table, "Assigned to", Or(item.AssignedTo));
        AddRow(table, "Iteration", Or(item.IterationPath));
        AddRow(table, "Area", Or(item.AreaPath));

        if (!string.IsNullOrWhiteSpace(item.Tags))
            AddRow(table, "Tags", item.Tags);

        AddRow(table, "Link", item.WebUrl);
    }

    private static void AddRow(Table table, string label, string value)
    {
        var row = table.AddRow();
        row.Cells[0].Shading.Color = Color.FromRgb(244, 246, 248);

        var key = row.Cells[0].AddParagraph(label);
        key.Format.Font.Bold = true;
        key.Format.Font.Size = 9.5;
        key.Format.SpaceAfter = Unit.FromPoint(2);

        var text = row.Cells[1].AddParagraph(value);
        text.Format.Font.Size = 9.5;
        text.Format.SpaceAfter = Unit.FromPoint(2);
    }

    private static void AddSection(Section section, string heading, string body)
    {
        section.AddParagraph(heading, "Heading2");
        if (string.IsNullOrWhiteSpace(body))
        {
            AddBody(section, "Not provided.", italic: true);
            return;
        }

        foreach (var line in body.Split('\n'))
        {
            if (string.IsNullOrWhiteSpace(line))
                continue;

            AddBody(section, line.TrimEnd());
        }
    }

    private static void AddBody(Section section, string text, bool italic = false)
    {
        var paragraph = section.AddParagraph(text);
        paragraph.Format.Font.Italic = italic;
        if (italic)
            paragraph.Format.Font.Color = Color.FromRgb(130, 130, 130);
    }

    private static string Or(string value) => string.IsNullOrWhiteSpace(value) ? "—" : value;
}
