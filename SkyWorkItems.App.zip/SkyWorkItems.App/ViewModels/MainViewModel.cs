using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SkyWorkItems.Configuration;
using SkyWorkItems.Models;
using SkyWorkItems.Services.Ai;
using SkyWorkItems.Services.DevOps;
using SkyWorkItems.Services.Export;
using SkyWorkItems.Services.Shell;

namespace SkyWorkItems.ViewModels;

public sealed partial class MainViewModel : ObservableObject
{
    private readonly IAzureDevOpsClient _devOps;
    private readonly IExportService _export;
    private readonly IStoryChatService _chat;
    private readonly IFolderPicker _folderPicker;
    private readonly AppSettings _settings;
    private readonly ILogger<MainViewModel> _log;

    public MainViewModel(
        IAzureDevOpsClient devOps,
        IExportService export,
        IStoryChatService chat,
        IFolderPicker folderPicker,
        IOptions<AppSettings> settings,
        ILogger<MainViewModel> log)
    {
        _devOps = devOps;
        _export = export;
        _chat = chat;
        _folderPicker = folderPicker;
        _settings = settings.Value;
        _log = log;

        OutputDirectory = _settings.Export.ResolveDirectory();
        SelectedFormat = _settings.Export.Format;
        Status = $"{_settings.AzureDevOps.Organization} / {_settings.AzureDevOps.Project} — ready.";
    }

    // ----- collections -------------------------------------------------------

    public ObservableCollection<TeamRef> Teams { get; } = [];
    public ObservableCollection<IterationRef> Iterations { get; } = [];
    public ObservableCollection<WorkItemSummary> WorkItems { get; } = [];
    public ObservableCollection<ChatTurn> Conversation { get; } = [];
    public string[] Formats { get; } = ["Both", "Markdown", "Pdf"];

    // ----- state -------------------------------------------------------------

    [ObservableProperty] private TeamRef? _selectedTeam;
    [ObservableProperty] private IterationRef? _selectedIteration;
    [ObservableProperty] private WorkItemSummary? _selectedWorkItem;
    [ObservableProperty] private WorkItemDetail? _detail;
    [ObservableProperty] private string _selectedFormat = "Both";
    [ObservableProperty] private string _outputDirectory = string.Empty;
    [ObservableProperty] private string _status = string.Empty;
    [ObservableProperty] private string _question = string.Empty;

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(IsIdle))]
    private bool _isBusy;

    public bool IsIdle => !IsBusy;

    public bool IsChatConfigured => _chat.IsConfigured;

    public string AgentName => _chat.AgentName;

    public string ProjectCaption =>
        $"{_settings.AzureDevOps.Organization} / {_settings.AzureDevOps.Project}";

    // ----- reacting to selection --------------------------------------------

    partial void OnSelectedTeamChanged(TeamRef? value)
    {
        if (value is not null)
            _ = LoadIterationsAsync();
    }

    partial void OnSelectedWorkItemChanged(WorkItemSummary? value)
    {
        Conversation.Clear();
        Detail = null;

        if (value is not null)
            _ = LoadDetailAsync(value.Id);
    }

    // ----- commands ----------------------------------------------------------

    [RelayCommand]
    private async Task LoadTeamsAsync()
    {
        await RunAsync("Loading teams…", async ct =>
        {
            var teams = await _devOps.GetTeamsAsync(ct);

            Teams.Clear();
            foreach (var team in teams)
                Teams.Add(team);

            Status = $"Loaded {Teams.Count} team(s).";
        });
    }

    [RelayCommand]
    private async Task LoadIterationsAsync()
    {
        if (SelectedTeam is null)
            return;

        await RunAsync("Loading sprints…", async ct =>
        {
            var iterations = await _devOps.GetIterationsAsync(SelectedTeam.Name, ct);

            Iterations.Clear();
            foreach (var iteration in iterations)
                Iterations.Add(iteration);

            SelectedIteration = Iterations.FirstOrDefault(i =>
                i.StartDate <= DateTime.Today && i.FinishDate >= DateTime.Today)
                ?? Iterations.FirstOrDefault();

            Status = $"Loaded {Iterations.Count} sprint(s) for {SelectedTeam.Name}.";
        });
    }

    [RelayCommand]
    private async Task LoadWorkItemsAsync()
    {
        if (SelectedTeam is null || SelectedIteration is null)
        {
            Status = "Pick a team and a sprint first.";
            return;
        }

        await RunAsync("Querying work items…", async ct =>
        {
            WorkItems.Clear();
            Detail = null;
            Conversation.Clear();

            var ids = await _devOps.QueryWorkItemIdsAsync(SelectedTeam.Name, SelectedIteration.Path, ct);
            if (ids.Count == 0)
            {
                Status = $"No work items in {SelectedIteration.Path}.";
                return;
            }

            foreach (var summary in await _devOps.GetSummariesAsync(ids, ct))
                WorkItems.Add(summary);

            Status = $"Loaded {WorkItems.Count} work item(s) from {SelectedIteration.Path}.";
        });
    }

    [RelayCommand]
    private async Task ExportSelectedAsync()
    {
        var ids = WorkItems.Where(w => w.IsSelected).Select(w => w.Id).ToList();
        if (ids.Count == 0)
        {
            Status = "Tick at least one work item to export.";
            return;
        }

        await RunAsync($"Exporting {ids.Count} work item(s)…", async ct =>
        {
            var progress = new Progress<string>(message => Status = message);
            var result = await _export.ExportAsync(ids, SelectedFormat, OutputDirectory, progress, ct);

            Status = result.Failures.Count == 0
                ? $"Wrote {result.Files.Count} file(s) to {result.OutputDirectory}."
                : $"Wrote {result.Files.Count} file(s); {result.Failures.Count} failed. "
                  + $"First failure — {result.Failures[0]}";
        });
    }

    [RelayCommand]
    private void BrowseOutputFolder()
    {
        var picked = _folderPicker.Pick("Choose where the exported files go", OutputDirectory);
        if (!string.IsNullOrWhiteSpace(picked))
            OutputDirectory = picked;
    }

    [RelayCommand]
    private void OpenOutputFolder()
    {
        Directory.CreateDirectory(OutputDirectory);
        Process.Start(new ProcessStartInfo(OutputDirectory) { UseShellExecute = true });
    }

    [RelayCommand]
    private void OpenInDevOps()
    {
        if (Detail is null || string.IsNullOrWhiteSpace(Detail.WebUrl))
            return;

        Process.Start(new ProcessStartInfo(Detail.WebUrl) { UseShellExecute = true });
    }

    [RelayCommand]
    private async Task AskAsync()
    {
        if (Detail is null)
        {
            Status = "Select a work item first.";
            return;
        }

        var question = Question?.Trim();
        if (string.IsNullOrEmpty(question))
            return;

        if (!_chat.IsConfigured)
        {
            Status = "Fill in the Ai section of appsettings.json to enable chat.";
            return;
        }

        Question = string.Empty;
        var history = Conversation.ToList();
        Conversation.Add(ChatTurn.User(question));

        await RunAsync($"{AgentName} is thinking…", async ct =>
        {
            var answer = await _chat.AskAsync(Detail, history, question, ct);
            Conversation.Add(ChatTurn.Assistant(AgentName, answer));
            Status = "Answer received.";
        });
    }

    [RelayCommand]
    private void SelectAll() => SetAllSelected(true);

    [RelayCommand]
    private void SelectNone() => SetAllSelected(false);

    // ----- helpers -----------------------------------------------------------

    private async Task LoadDetailAsync(int id)
    {
        await RunAsync($"Loading work item {id}…", async ct =>
        {
            Detail = await _devOps.GetDetailAsync(id, ct);
            Status = $"Loaded work item {id}.";
        });
    }

    private void SetAllSelected(bool value)
    {
        foreach (var item in WorkItems)
            item.IsSelected = value;
    }

    /// <summary>One place for busy state, cancellation and error reporting.</summary>
    private async Task RunAsync(string busyMessage, Func<CancellationToken, Task> work)
    {
        if (IsBusy)
            return;

        IsBusy = true;
        Status = busyMessage;

        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(10));
            await work(cts.Token);
        }
        catch (OperationCanceledException)
        {
            Status = "Cancelled.";
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Operation failed: {Message}", busyMessage);
            Status = "Error: " + ex.Message.Replace('\n', ' ');
        }
        finally
        {
            IsBusy = false;
        }
    }
}
