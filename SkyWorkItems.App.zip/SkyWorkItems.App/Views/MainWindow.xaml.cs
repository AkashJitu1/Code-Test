using System.Windows;
using SkyWorkItems.ViewModels;

namespace SkyWorkItems.Views;

public partial class MainWindow : Window
{
    public MainWindow(MainViewModel viewModel)
    {
        InitializeComponent();
        DataContext = viewModel;

        // Teams are the entry point for everything else, so load them on open.
        Loaded += async (_, _) => await viewModel.LoadTeamsCommand.ExecuteAsync(null);
    }
}
