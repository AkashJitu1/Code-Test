# CodeCompass

A WPF desktop agent that reads your local folders (thousands of files), builds a searchable
index over them, and answers questions about that content using Semantic Kernel.

- **.NET 10**, WPF, MVVM, no third-party MVVM framework
- **Semantic Kernel** for chat completion
- **GitHub Models / GitHub Copilot-backed endpoint** by default — any OpenAI-compatible endpoint works
- **Everything configurable in `App.config`** — no recompilation to change folders, models or behaviour
- Answers are **grounded**: every reply cites `file path (lines N-M)`

---

## 1. Prerequisites

| Requirement | Notes |
|---|---|
| Windows 10 1809+ / Windows 11 | WPF target |
| .NET 10 SDK | `dotnet --version` should print `10.x` |
| Visual Studio 2026 (or 2022 17.14+) | Optional — `dotnet run` works too |
| A GitHub token | Fine-grained PAT with the **Models** permission, or a classic PAT |

### Getting the token

1. Go to **GitHub → Settings → Developer settings → Personal access tokens**.
2. Create a token and enable the **Models** scope (this is what GitHub Copilot subscribers use
   to reach the hosted models programmatically).
3. Store it as an environment variable so it never lands in source control:

```powershell
setx GITHUB_TOKEN "github_pat_xxxxxxxxxxxxxxxx"
```

Close and reopen Visual Studio / your terminal afterwards so the variable is picked up.

> **A note on wording.** GitHub Copilot's in-editor chat endpoint is not a public, documented API.
> The supported programmatic route for the same models is **GitHub Models**
> (`https://models.github.ai/inference`), which speaks the OpenAI wire format. That is what this app
> targets by default. Because the endpoint is a config value, you can repoint it at Azure OpenAI,
> OpenAI, an internal gateway, or a local Ollama instance without touching code.

---

## 2. Build and run

```powershell
git clone <your-repo> CodeCompass
cd CodeCompass
dotnet restore
dotnet build -c Release
dotnet run --project src\CodeCompass.App
```

Or open `CodeCompass.sln`, set **CodeCompass.App** as the startup project, press F5.

---

## 3. Configure

Everything lives in `src/CodeCompass.App/App.config` under `<appSettings>`.

### 3.1 Model provider

| Key | Default | Meaning |
|---|---|---|
| `Model.Endpoint` | `https://models.github.ai/inference` | Base URL of an OpenAI-compatible API |
| `Model.ApiKey` | `env:GITHUB_TOKEN` | `env:NAME` reads environment variable `NAME`. A literal token also works |
| `Model.ChatModelId` | `openai/gpt-4o` | Chat model |
| `Model.EmbeddingModelId` | `openai/text-embedding-3-small` | Embedding model |
| `Model.Temperature` | `0.2` | Low is right for factual code Q&A |
| `Model.MaxResponseTokens` | `1200` | Answer length cap |
| `Model.RequestTimeoutSeconds` | `120` | HTTP timeout |

Provider swap examples:

```xml
<!-- Azure OpenAI -->
<add key="Model.Endpoint"    value="https://my-resource.openai.azure.com/openai/v1" />
<add key="Model.ApiKey"      value="env:AZURE_OPENAI_KEY" />
<add key="Model.ChatModelId" value="gpt-4o-deployment" />

<!-- Fully offline with Ollama -->
<add key="Model.Endpoint"          value="http://localhost:11434/v1" />
<add key="Model.ApiKey"            value="ollama" />
<add key="Model.ChatModelId"       value="qwen2.5-coder:14b" />
<add key="Model.EmbeddingModelId"  value="nomic-embed-text" />
```

### 3.2 What gets indexed

| Key | Default | Meaning |
|---|---|---|
| `Index.Roots` | *(set this)* | One or more folders, separated by `;`. `%USERPROFILE%` style variables are expanded |
| `Index.IncludeExtensions` | `.cs;.ts;.js;...` | Allow-list. Anything not listed is ignored |
| `Index.ExcludeDirectories` | `bin;obj;node_modules;.git;...` | Folder names skipped anywhere in the tree |
| `Index.MaxFileSizeKB` | `512` | Files larger than this are skipped (generated files, minified bundles) |
| `Index.ChunkSizeChars` | `1600` | Roughly 400 tokens per chunk |
| `Index.ChunkOverlapChars` | `200` | Overlap so a method split across chunks stays understandable |
| `Index.EmbeddingBatchSize` | `32` | Texts per embedding request |
| `Index.FilePath` | `%LOCALAPPDATA%\CodeCompass\index.bin` | Where the built index is cached |

**This is the one line you must edit before first run:**

```xml
<add key="Index.Roots" value="C:\Work\MyRepo\src;C:\Work\MyRepo\docs" />
```

### 3.3 Retrieval

| Key | Default | Meaning |
|---|---|---|
| `Retrieval.Mode` | `Hybrid` | `Lexical`, `Vector` or `Hybrid` |
| `Retrieval.TopK` | `8` | Extracts sent to the model per question |
| `Retrieval.CandidatePoolSize` | `40` | Candidates each strategy returns before fusion |
| `Retrieval.MaxContextCharacters` | `24000` | Hard cap on context size |
| `Retrieval.MaxHistoryTurns` | `8` | Conversation turns kept for follow-ups |

**Mode guide**

- `Lexical` — BM25 keyword search only. **No embedding calls at all**, so indexing 1000+ files takes
  seconds and costs nothing. Start here.
- `Vector` — embeddings only. Best for "where do we handle retries?" style conceptual questions.
- `Hybrid` — both, fused with Reciprocal Rank Fusion. Best quality, and it still works if the
  embedding endpoint is rate-limited (the failing strategy is skipped, not fatal).

### 3.4 Agent behaviour

`Agent.SystemPrompt` controls tone and grounding rules. `App.LogFilePath` sets the log location.

---

## 4. Using the app

1. **Build index** (left rail). Progress and the current file show at the bottom.
   For ~1000 files this is seconds in `Lexical` mode, a few minutes in `Hybrid`.
2. The index is written to disk and **reloaded automatically on next launch** —
   you only rebuild when the files change.
3. Type a question, press **Ask** or **Ctrl+Enter**.
4. The answer streams in. Amber chips underneath list exactly which file extracts were used.
5. **Stop** cancels an in-flight build or answer. **Clear** resets the conversation.

### Questions that work well

```
Where is the retry policy for outbound HTTP calls defined?
Summarise what OrderService does and list its dependencies.
Which files write to the Payments table?
What validation runs before a claim is submitted?
Explain the difference between the two IRepository implementations.
```

### Questions that will not work

Anything needing the *whole* corpus at once — "how many classes are in the solution", "list every
TODO". Retrieval sends the top K extracts, not all 1000 files. Narrow the question, or lower
`Index.Roots` to a subfolder and rebuild.

---

## 5. How it works

```
Folders ──► IFileScanner ──► IFileFilter ──► ITextChunker ──► IEmbeddingClient
                                                                    │
                                                              IIndexStore (index.bin)
                                                                    │
Question ──► IRetriever ──┬─ LexicalScorer (BM25)  ─┐               │
                          └─ VectorScorer (cosine) ─┴─ RRF fusion ◄──┘
                                    │
                             IPromptBuilder ──► ICodeAgent ──► Semantic Kernel ──► model
                                    │
                                  WPF UI (streamed answer + citations)
```

### SOLID, concretely

- **Single responsibility** — scanning, filtering, chunking, embedding, storage, ranking, prompt
  assembly and chat are eight separate types. `IndexBuilder` only sequences them.
- **Open/closed** — to add a new ranking strategy (symbol search, recency boost), implement
  `IScorer` and register it. `HybridRetriever` does not change.
- **Liskov** — `NullEmbeddingClient` and `NoOpScorer` are drop-in substitutes used when a
  strategy is switched off in config; nothing downstream branches on type.
- **Interface segregation** — narrow interfaces (`IFileFilter` has two methods) rather than one
  service interface.
- **Dependency inversion** — every class depends on abstractions. `App.xaml.cs` is the only file
  that names concrete types, and it is the only file you change to swap an implementation.

### Design decisions worth knowing

- **Binary index format, not JSON.** 20,000 chunks × 1536 floats is roughly 120 MB as float32 and
  several hundred MB as JSON text. `BinaryIndexStore` writes float32 directly.
- **Iterative directory walk.** A `Stack<string>` rather than recursion, so a deep tree cannot
  overflow the stack and one unreadable folder does not abort the scan.
- **Line-aware chunking.** Chunks break on line boundaries and carry their line range, which is
  what makes `OrderService.cs (lines 40-78)` citations possible.
- **Scorer failures are non-fatal.** If the embedding endpoint returns 429, keyword search still
  answers the question.
- **Streaming answers.** `IAsyncEnumerable<string>` from Semantic Kernel straight into the
  ViewModel, so text appears as it is generated.

---

## 6. Scale and cost

| Corpus | Chunks (approx) | Lexical build | Hybrid build | Memory |
|---|---|---|---|---|
| 1,000 files | ~8,000 | 5–15 s | 3–8 min | ~60 MB |
| 5,000 files | ~40,000 | 30–60 s | 15–40 min | ~280 MB |

Hybrid build time is dominated by embedding round-trips and provider rate limits. The index is
cached, so this is a one-off per change to the source folders.

If a large corpus is slow or memory-heavy: raise `Index.ChunkSizeChars` to 2400, tighten
`Index.IncludeExtensions`, or run in `Lexical` mode.

---

## 7. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| "No API token found" | `GITHUB_TOKEN` is not set, or the terminal predates `setx`. Reopen it |
| 401 from the endpoint | Token lacks the Models permission, or it expired |
| 404 on the model | `Model.ChatModelId` must match the provider's naming. GitHub Models uses `publisher/model`, for example `openai/gpt-4o` |
| 429 rate limited | Lower `Index.EmbeddingBatchSize`, or build in `Lexical` mode |
| "No index loaded" | Select **Build index**. Check `Index.Roots` points at folders that exist |
| Index build finds 0 files | Your file extensions are not in `Index.IncludeExtensions` |
| Answers ignore an obvious file | Raise `Retrieval.TopK`, or make the question mention the file or type name |
| Nothing in the log | Check `%LOCALAPPDATA%\CodeCompass\app.log` |

---

## 8. Project layout

```
CodeCompass.sln
global.json
src/
  CodeCompass.Core/                 # No WPF reference. Testable in isolation.
    Abstractions/                   # 12 interfaces — the contract surface
    Models/                         # SourceFile, DocumentChunk, SearchHit, IndexSnapshot...
    Configuration/AppConfigSettings.cs
    Services/
      FileSystemScanner.cs          ExtensionFileFilter.cs
      LineAwareChunker.cs           OpenAiCompatibleEmbeddingClient.cs
      BinaryIndexStore.cs           IndexBuilder.cs
      LexicalScorer.cs              VectorScorer.cs
      HybridRetriever.cs            GroundedPromptBuilder.cs
      KernelFactory.cs              SemanticKernelCodeAgent.cs
      FileAppLogger.cs              NullEmbeddingClient.cs
  CodeCompass.App/                  # WPF, MVVM
    App.config                      # ← all configuration
    App.xaml.cs                     # ← composition root (the only place concrete types appear)
    ViewModels/  MainViewModel, ObservableObject, AsyncRelayCommand, MessageViewModel
    Views/       MainWindow.xaml, Theme.xaml
    Infrastructure/NoOpScorer.cs
```

---

## 9. Extending it

**Add a file type** — append the extension to `Index.IncludeExtensions`. No code change.

**Add a ranking strategy** — implement `IScorer`, register it in `App.xaml.cs`. RRF picks it up.

**Incremental indexing** — `SourceFile` already carries `LastWriteUtc`. Compare it against the
loaded snapshot in `IndexBuilder` and re-embed only changed files.

**Semantic Kernel plugins** — `KernelFactory.Create()` is the place to call
`builder.Plugins.AddFromType<T>()` if you want the agent to run tools rather than only read text.

**Unit tests** — `CodeCompass.Core` has no UI dependency. `AppConfigSettings` accepts a
`Func<string, string?>` in its second constructor specifically so tests can supply settings
without an `App.config`.

---

## 10. A caveat on this drop

This code was written against the .NET 10 and Semantic Kernel 1.65 APIs but was **not compiled on
this machine** (no Windows SDK and no NuGet access in the authoring environment). Expect to fix
package versions in the two `.csproj` files if 1.65 has moved on — `dotnet restore` will tell you
immediately. The architecture and logic are the substance here; a version bump is a one-line edit.
